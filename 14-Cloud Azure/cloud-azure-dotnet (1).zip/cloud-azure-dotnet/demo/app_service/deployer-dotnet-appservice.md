# Déployer un projet .NET sur Azure App Service — Interface graphique

## Prérequis

Avant de commencer, assurez-vous d'avoir :

- Un **compte Azure actif** (créez-en un gratuitement sur portal.azure.com — 200$ de crédits pendant 30 jours)
- Le **.NET 8 SDK** installé (vérifiez avec `dotnet --version`)
- **Visual Studio 2022** avec la charge de travail « ASP.NET et développement web », ou **VS Code** avec l'extension C#
- Un **projet Blazor prêt** et testé en local (`dotnet run`)

---

## Étape 1 — Créer un Resource Group

1. Connectez-vous à **portal.azure.com**
2. Cliquez sur **« Créer une ressource »** (bouton en haut à gauche)
3. Recherchez **« Resource Group »** dans la barre de recherche
4. Cliquez **« Créer »**
5. Remplissez le formulaire :
   - **Abonnement** : sélectionnez votre abonnement
   - **Nom du groupe de ressources** : `rg-blazor-demo`
   - **Région** : `France Central` (ou la région la plus proche de vos utilisateurs)
6. Cliquez **« Vérifier + créer »** puis **« Créer »**

> **Conseil** : le Resource Group est un conteneur logique qui regroupe toutes les ressources liées à votre projet. Utilisez une convention de nommage cohérente (ex : `rg-<projet>-<env>`).

---

## Étape 2 — Créer un App Service Plan

Le plan App Service définit les ressources de calcul (CPU, RAM) allouées à votre application.

| SKU | Tarif | CPU / RAM | Always On | Usage recommandé |
|-----|-------|-----------|-----------|------------------|
| F1 (Gratuit) | 0 € | Partagé / 1 Go | ❌ | Tests uniquement |
| B1 (Basic) | ~12 €/mois | 1 vCPU / 1.75 Go | ✅ | Dev / Staging |
| S1 (Standard) | ~65 €/mois | 1 vCPU / 1.75 Go | ✅ | Production |
| P1v3 (Premium) | ~120 €/mois | 2 vCPU / 8 Go | ✅ | Haute performance |

> **Recommandation** : pour un projet Blazor Server, choisissez au minimum **B1** pour bénéficier de Always On et éviter les cold starts. En production, **S1** est conseillé.

Le plan sera créé automatiquement lors de la création de la Web App (étape suivante), mais vous pouvez aussi le créer séparément via « Créer une ressource » → « App Service Plan ».

---

## Étape 3 — Créer la Web App

1. Dans le portail Azure, cliquez **« Créer une ressource »**
2. Recherchez **« Web App »** et cliquez **« Créer »**
3. Remplissez l'onglet **Informations de base** :
   - **Abonnement** : votre abonnement
   - **Groupe de ressources** : `rg-blazor-demo`
   - **Nom** : `blazor-app-2itech` (ce sera votre URL : `blazor-app-2itech.azurewebsites.net`)
   - **Publier** : `Code`
   - **Pile d'exécution** : `.NET 8 (LTS)`
   - **Système d'exploitation** : `Linux`
   - **Région** : `France Central`
   - **Plan App Service** : créez-en un nouveau ou sélectionnez un existant, avec le SKU souhaité (B1 minimum)
4. Onglet **Déploiement** : vous pouvez activer GitHub Actions ici ou le faire plus tard
5. Onglet **Mise en réseau** : laissez les valeurs par défaut (accès public activé)
6. Cliquez **« Vérifier + créer »** puis **« Créer »**
7. Attendez la fin du provisionnement (~1-2 minutes), puis cliquez **« Accéder à la ressource »**

---

## Étape 4 — Configurer les paramètres essentiels

Une fois la Web App créée, configurez ces trois paramètres indispensables.

### WebSockets (obligatoire pour Blazor Server)

1. Dans le menu gauche de votre Web App → **Configuration** → **Paramètres généraux**
2. Trouvez **« Web sockets »** et basculez sur **ON**
3. Cliquez **« Enregistrer »** en haut

> **⚠️ Sans WebSockets, Blazor Server ne fonctionnera pas.** SignalR utilise les WebSockets pour la communication temps réel entre le navigateur et le serveur.

### Always On (éviter les cold starts)

1. Toujours dans **Configuration** → **Paramètres généraux**
2. Trouvez **« Always On »** et basculez sur **ON**
3. Cliquez **« Enregistrer »**

> Disponible à partir du plan B1. Empêche Azure de mettre l'application en veille après une période d'inactivité.

### Health Check

1. Dans le menu gauche → **Surveillance** → **Contrôle d'intégrité**
2. Activez le contrôle et entrez le chemin : `/health`
3. Cliquez **« Enregistrer »**

> Azure vérifiera régulièrement cet endpoint. Si l'application ne répond plus, Azure la redémarrera automatiquement.

---

## Étape 5 — Déployer le code

Trois méthodes principales via l'interface graphique :

### Méthode A — Depuis Visual Studio (recommandé)

1. Ouvrez votre projet dans Visual Studio
2. Clic droit sur le projet dans l'Explorateur de solutions → **« Publier... »**
3. Sélectionnez **Azure** comme cible → **Suivant**
4. Sélectionnez **Azure App Service (Linux)** → **Suivant**
5. Connectez-vous à votre compte Azure si nécessaire
6. Sélectionnez votre abonnement, puis la Web App créée précédemment (`blazor-app-2itech`)
7. Cliquez **« Terminer »** puis **« Publier »**
8. Visual Studio compile, publie et déploie. Le navigateur s'ouvre automatiquement sur votre application.

### Méthode B — Centre de déploiement (CI/CD avec GitHub)

1. Dans le portail Azure, ouvrez votre Web App
2. Menu gauche → **Centre de déploiement**
3. **Source** : sélectionnez `GitHub`
4. Autorisez Azure à accéder à votre compte GitHub
5. Sélectionnez votre **Organisation**, **Dépôt** et **Branche** (ex : `main`)
6. Azure génère automatiquement un fichier GitHub Actions dans votre dépôt
7. Cliquez **« Enregistrer »**

À partir de maintenant, chaque `git push` sur la branche `main` déclenchera automatiquement le build et le déploiement.

### Méthode C — Déploiement ZIP via Kudu

1. Publiez votre projet en local :
   ```bash
   dotnet publish -c Release -o ./publish
   ```
2. Zippez le contenu du dossier `publish`
3. Dans le portail Azure, ouvrez votre Web App
4. Menu gauche → **Outils avancés** → **Accéder** (ouvre Kudu)
5. Allez dans **Tools** → **Zip Push Deploy**
6. Glissez-déposez votre fichier `.zip`

---

## Étape 6 — Vérifier et monitorer

### Vérification

- Ouvrez l'URL de votre app : `https://blazor-app-2itech.azurewebsites.net`
- Testez le Health Check : `https://blazor-app-2itech.azurewebsites.net/health`
- Naviguez dans les différentes pages (Compteur, Météo, Info Serveur)
- Sur la page Info Serveur, vérifiez que les variables Azure (`WEBSITE_SITE_NAME`, `REGION_NAME`) sont renseignées

### Monitoring

- **Vue d'ensemble** : dans le portail, la page principale de votre Web App affiche les requêtes, temps de réponse et erreurs en temps réel
- **Métriques** : menu gauche → Surveillance → Métriques (CPU, Mémoire, Connexions HTTP)
- **Flux de journaux** : menu gauche → Surveillance → Flux de journaux (logs en temps réel)
- **Application Insights** : activez-le pour des traces détaillées, exceptions et données de performance (optionnel mais recommandé en production)
- **Diagnostiquer et résoudre les problèmes** : menu dédié pour identifier rapidement les erreurs 500, timeouts ou problèmes de démarrage

---

## Dépannage — Problèmes courants

**Page blanche ou erreur de connexion SignalR**
Cause : WebSockets non activés. Solution : Configuration → Paramètres généraux → Web Sockets → ON.

**Application lente au premier accès**
Cause : cold start (Always On désactivé). Solution : Configuration → Paramètres généraux → Always On → ON (plan B1 minimum).

**Erreur 500 au démarrage**
Cause : runtime incorrect ou dépendances manquantes. Solution : vérifiez que la pile d'exécution est bien `.NET 8`. Consultez les logs dans Flux de journaux.

**Déploiement échoue depuis Visual Studio**
Cause : profil de publication mal configuré. Solution : supprimez le profil de publication et recréez-le. Vérifiez l'abonnement et les droits d'accès.

---

## Récapitulatif

Le flux complet en 6 étapes :

**Resource Group** → **App Service Plan** → **Web App** → **Configurer (WebSockets, Always On, Health Check)** → **Déployer le code** → **Vérifier & Monitorer**

Points essentiels à retenir :

- **WebSockets** = obligatoire pour Blazor Server (SignalR)
- **Always On** = éviter les temps de démarrage à froid
- **Health Check /health** = supervision automatique par Azure
- **SKU B1 minimum** pour Always On (F1 = tests uniquement)
- **Linux** recommandé = meilleur rapport qualité/prix
