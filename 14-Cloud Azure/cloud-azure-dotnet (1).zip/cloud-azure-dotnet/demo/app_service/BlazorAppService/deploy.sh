#!/bin/bash
# ============================================================
# Script de déploiement - Blazor App Service
# ============================================================
# Usage : ./deploy.sh [nom-webapp] [resource-group] [location]
# ============================================================

set -e

# === PARAMÈTRES (modifiables) ===
APP_NAME="${1:-blazor-app-demo}"
RESOURCE_GROUP="${2:-rg-blazor-demo}"
LOCATION="${3:-francecentral}"
PLAN_NAME="plan-${APP_NAME}"
SKU="B1"

echo "=========================================="
echo "  Déploiement Blazor sur Azure App Service"
echo "=========================================="
echo "  App Name       : $APP_NAME"
echo "  Resource Group  : $RESOURCE_GROUP"
echo "  Location        : $LOCATION"
echo "  SKU             : $SKU"
echo "=========================================="

# 1. Vérifier la connexion Azure
echo ""
echo "🔐 Vérification de la connexion Azure..."
az account show > /dev/null 2>&1 || { echo "❌ Veuillez vous connecter : az login"; exit 1; }
echo "✅ Connecté à Azure"

# 2. Créer le Resource Group
echo ""
echo "📦 Création du Resource Group..."
az group create --name "$RESOURCE_GROUP" --location "$LOCATION" --output none
echo "✅ Resource Group '$RESOURCE_GROUP' créé"

# 3. Créer le App Service Plan
echo ""
echo "📋 Création du App Service Plan..."
az appservice plan create \
  --name "$PLAN_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --sku "$SKU" \
  --is-linux \
  --output none
echo "✅ Plan '$PLAN_NAME' créé (SKU: $SKU)"

# 4. Créer la Web App
echo ""
echo "🌐 Création de la Web App..."
az webapp create \
  --name "$APP_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --plan "$PLAN_NAME" \
  --runtime "DOTNETCORE:8.0" \
  --output none
echo "✅ Web App '$APP_NAME' créée"

# 5. Configurer les paramètres
echo ""
echo "⚙️ Configuration de la Web App..."
az webapp config set \
  --resource-group "$RESOURCE_GROUP" \
  --name "$APP_NAME" \
  --web-sockets-enabled true \
  --always-on true \
  --output none
echo "✅ WebSockets et Always On activés"

# 6. Build et Publish
echo ""
echo "🔨 Build de l'application..."
dotnet publish -c Release -o ./publish --nologo -v quiet
echo "✅ Application compilée"

# 7. Zipper
echo ""
echo "📦 Création du package..."
cd publish
zip -r ../deploy.zip . -q
cd ..
echo "✅ Package créé (deploy.zip)"

# 8. Déployer
echo ""
echo "🚀 Déploiement en cours..."
az webapp deploy \
  --resource-group "$RESOURCE_GROUP" \
  --name "$APP_NAME" \
  --src-path deploy.zip \
  --type zip \
  --output none
echo "✅ Déploiement terminé !"

# 9. Résultat
APP_URL="https://${APP_NAME}.azurewebsites.net"
HEALTH_URL="${APP_URL}/health"
echo ""
echo "=========================================="
echo "  ✅ DÉPLOIEMENT RÉUSSI !"
echo "=========================================="
echo "  🌐 URL : $APP_URL"
echo "  🏥 Health : $HEALTH_URL"
echo "=========================================="
echo ""
echo "Pour ouvrir dans le navigateur :"
echo "  az webapp browse --name $APP_NAME --resource-group $RESOURCE_GROUP"
echo ""
echo "Pour voir les logs :"
echo "  az webapp log tail --name $APP_NAME --resource-group $RESOURCE_GROUP"

# Nettoyage
rm -rf ./publish deploy.zip
