# BlazorAppService

Application **Blazor Server (.NET 8)** prête pour le déploiement sur **Azure App Service**.

## Fonctionnalités

- Blazor Interactive Server (SignalR)
- Health Check endpoint (`/health`)
- Page d'informations serveur (variables Azure)
- Pipeline Azure DevOps CI/CD inclus
- Dockerfile pour déploiement conteneurisé
- Script de déploiement automatisé

## Démarrage rapide

```bash
# Lancer en local
dotnet run

# Ouvrir https://localhost:5001
```

## Déploiement sur Azure

### Option 1 : Script automatisé

```bash
chmod +x deploy.sh
./deploy.sh mon-app-blazor rg-blazor francecentral
```

### Option 2 : Commandes manuelles

```bash
az login
az group create --name rg-blazor --location francecentral
az appservice plan create --name plan-blazor --resource-group rg-blazor --sku B1 --is-linux
az webapp create --name mon-app-blazor --resource-group rg-blazor --plan plan-blazor --runtime "DOTNETCORE:8.0"
az webapp config set --resource-group rg-blazor --name mon-app-blazor --web-sockets-enabled true --always-on true
dotnet publish -c Release -o ./publish
cd publish && zip -r ../deploy.zip . && cd ..
az webapp deploy --resource-group rg-blazor --name mon-app-blazor --src-path deploy.zip --type zip
```

### Option 3 : Azure DevOps Pipeline

1. Pousser le code sur Azure Repos
2. Modifier `azure-pipelines.yml` : remplacer `YOUR_SERVICE_CONNECTION` et `YOUR_WEBAPP_NAME`
3. Créer un pipeline dans Azure DevOps pointant sur ce fichier

### Option 4 : Docker

```bash
docker build -t blazor-app .
docker run -p 8080:8080 blazor-app
```

## Configuration Azure importante

| Paramètre | Valeur | Raison |
|---|---|---|
| WebSockets | `true` | Requis pour SignalR (Blazor Server) |
| Always On | `true` | Éviter le cold start |
| Health Check | `/health` | Supervision Azure |
| SKU minimum | B1 | Supporte Always On |

## Structure

```
BlazorAppService/
├── Components/
│   ├── Layout/          # MainLayout, NavMenu
│   └── Pages/           # Home, Counter, Weather, ServerInfo
├── Properties/          # launchSettings.json
├── wwwroot/css/         # Styles
├── Program.cs           # Point d'entrée
├── azure-pipelines.yml  # CI/CD Azure DevOps
├── deploy.sh            # Script de déploiement
└── Dockerfile           # Build conteneurisé
```
