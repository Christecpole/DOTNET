using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorTodo.Models;
using RazorTodo.Services;

namespace RazorTodo.Pages;

public class IndexModel : PageModel
{
    private readonly TodoService _todoService;

    public IndexModel(TodoService todoService)
    {
        _todoService = todoService;
    }

    // ────────── Propriétés de la page ──────────
    public List<TodoItem> Todos { get; set; } = new();
    public List<TodoItem> FilteredTodos { get; set; } = new();
    public int TotalCount { get; set; }
    public int PendingCount { get; set; }
    public int CompletedCount { get; set; }

    [BindProperty(SupportsGet = true)]
    public string Filter { get; set; } = "all";

    [BindProperty(SupportsGet = true)]
    public int? EditId { get; set; }

    // ────────── Formulaire ──────────
    [BindProperty]
    public string Title { get; set; } = string.Empty;

    [BindProperty]
    public string? Description { get; set; }

    [BindProperty]
    public string Priority { get; set; } = "Normal";

    // ────────── Item en édition ──────────
    public TodoItem? EditingItem { get; set; }

    // ────────── GET ──────────
    public void OnGet()
    {
        LoadData();

        if (EditId.HasValue)
        {
            EditingItem = _todoService.GetById(EditId.Value);
            if (EditingItem != null)
            {
                Title = EditingItem.Title;
                Description = EditingItem.Description;
                Priority = EditingItem.Priority;
            }
        }
    }

    // ────────── POST : Ajouter ou Modifier ──────────
    public IActionResult OnPostAdd()
    {
        if (string.IsNullOrWhiteSpace(Title))
            return RedirectToPage(new { filter = Filter });

        if (EditId.HasValue && EditId.Value > 0)
        {
            _todoService.Update(new TodoItem
            {
                Id = EditId.Value,
                Title = Title,
                Description = Description,
                Priority = Priority
            });
        }
        else
        {
            _todoService.Add(new TodoItem
            {
                Title = Title,
                Description = Description,
                Priority = Priority
            });
        }

        return RedirectToPage(new { filter = Filter });
    }

    // ────────── POST : Toggle complet ──────────
    public IActionResult OnPostToggle(int id)
    {
        _todoService.ToggleComplete(id);
        return RedirectToPage(new { filter = Filter });
    }

    // ────────── POST : Supprimer ──────────
    public IActionResult OnPostDelete(int id)
    {
        _todoService.Delete(id);
        return RedirectToPage(new { filter = Filter });
    }

    // ────────── Charger les données ──────────
    private void LoadData()
    {
        Todos = _todoService.GetAll();
        TotalCount = _todoService.GetTotalCount();
        PendingCount = _todoService.GetPendingCount();
        CompletedCount = _todoService.GetCompletedCount();

        FilteredTodos = Filter switch
        {
            "pending" => Todos.Where(t => !t.IsCompleted).ToList(),
            "done" => Todos.Where(t => t.IsCompleted).ToList(),
            _ => Todos
        };
    }

    // ────────── Helpers pour la vue ──────────
    public string GetPriorityBadgeClass(string priority) => priority switch
    {
        "High" => "bg-danger",
        "Low" => "bg-secondary",
        _ => "bg-info"
    };

    public string GetPriorityLabel(string priority) => priority switch
    {
        "High" => "Haute",
        "Low" => "Basse",
        _ => "Normale"
    };
}
