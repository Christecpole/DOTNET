using RazorTodo.Models;

namespace RazorTodo.Services;

public class TodoService
{
    private readonly List<TodoItem> _todos = new();
    private int _nextId = 1;

    public TodoService()
    {
        Add(new TodoItem { Title = "Découvrir Razor Pages", Description = "Créer une app ASP.NET Core", Priority = "High" });
        Add(new TodoItem { Title = "Apprendre Docker", Description = "Conteneuriser une application .NET", Priority = "High" });
        Add(new TodoItem { Title = "Déployer sur Azure", Description = "Utiliser ACR et ACI", Priority = "Normal" });
        Add(new TodoItem { Title = "Configurer CI/CD", Description = "Pipeline Azure DevOps", Priority = "Low" });
    }

    public List<TodoItem> GetAll()
    {
        return _todos.OrderByDescending(t => t.Priority == "High")
                      .ThenByDescending(t => t.Priority == "Normal")
                      .ThenBy(t => t.IsCompleted)
                      .ThenByDescending(t => t.CreatedAt)
                      .ToList();
    }

    public TodoItem? GetById(int id) => _todos.FirstOrDefault(t => t.Id == id);

    public TodoItem Add(TodoItem item)
    {
        item.Id = _nextId++;
        item.CreatedAt = DateTime.Now;
        _todos.Add(item);
        return item;
    }

    public TodoItem? Update(TodoItem item)
    {
        var existing = GetById(item.Id);
        if (existing == null) return null;
        existing.Title = item.Title;
        existing.Description = item.Description;
        existing.Priority = item.Priority;
        return existing;
    }

    public bool Delete(int id)
    {
        var item = GetById(id);
        if (item == null) return false;
        return _todos.Remove(item);
    }

    public void ToggleComplete(int id)
    {
        var item = GetById(id);
        if (item == null) return;
        item.IsCompleted = !item.IsCompleted;
        item.CompletedAt = item.IsCompleted ? DateTime.Now : null;
    }

    public int GetCompletedCount() => _todos.Count(t => t.IsCompleted);
    public int GetPendingCount() => _todos.Count(t => !t.IsCompleted);
    public int GetTotalCount() => _todos.Count;
}
