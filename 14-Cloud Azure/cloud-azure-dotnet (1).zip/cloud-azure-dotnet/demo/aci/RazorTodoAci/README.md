# Razor Todo — Déploiement ACR / ACI

Application **ASP.NET Core Razor Pages (.NET 8)** — TodoList en mémoire (sans EF ni base de données), conteneurisée avec Docker et déployée sur **Azure Container Instances (ACI)** via **Azure Container Registry (ACR)**.

---

## Architecture

```
┌──────────┐     docker push      ┌──────────────┐     az container create     ┌──────────────┐
│  Local    │ ──────────────────▶  │  ACR          │ ─────────────────────────▶ │  ACI          │
│  Docker   │                      │  (Registry)   │                            │  (Container)  │
│  Build    │                      │               │                            │               │
└──────────┘                      └──────────────┘                             └──────────────┘
                                   Stocke l'image                               Exécute l'image
                                   Docker privée                                Accessible HTTP
```

---

## 1. Test en local

```bash
# Sans Docker
dotnet run
# → http://localhost:5000

# Avec Docker
docker build -t razor-todo .
docker run -d -p 8080:8080 --name razor-todo razor-todo
# → http://localhost:8080
```

---

## 2. Créer les ressources Azure

### 2.1 — Variables

```bash
RESOURCE_GROUP="rg-razor-todo"
LOCATION="francecentral"
ACR_NAME="acrrazortodo$RANDOM"
ACI_NAME="aci-razor-todo"
IMAGE_NAME="razor-todo"
IMAGE_TAG="v1"
```

### 2.2 — Resource Group

```bash
az group create \
  --name $RESOURCE_GROUP \
  --location $LOCATION
```

### 2.3 — Azure Container Registry (ACR)

```bash
az acr create \
  --name $ACR_NAME \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --sku Basic \
  --admin-enabled true
```

### 2.4 — Récupérer les identifiants ACR

```bash
ACR_LOGIN_SERVER=$(az acr show \
  --name $ACR_NAME \
  --query "loginServer" \
  --output tsv)

ACR_USERNAME=$(az acr credential show \
  --name $ACR_NAME \
  --query "username" \
  --output tsv)

ACR_PASSWORD=$(az acr credential show \
  --name $ACR_NAME \
  --query "passwords[0].value" \
  --output tsv)

echo "Login Server : $ACR_LOGIN_SERVER"
echo "Username     : $ACR_USERNAME"
```

---

## 3. Build et Push de l'image

### Option A — Build dans le cloud (recommandé)

```bash
az acr build \
  --registry $ACR_NAME \
  --image $IMAGE_NAME:$IMAGE_TAG \
  --file Dockerfile \
  .
```

### Option B — Build local + Push

```bash
docker login $ACR_LOGIN_SERVER -u $ACR_USERNAME -p $ACR_PASSWORD
docker build -t $ACR_LOGIN_SERVER/$IMAGE_NAME:$IMAGE_TAG .
docker push $ACR_LOGIN_SERVER/$IMAGE_NAME:$IMAGE_TAG
```

### Vérifier

```bash
az acr repository list --name $ACR_NAME --output table
az acr repository show-tags --name $ACR_NAME --repository $IMAGE_NAME --output table
```

---

## 4. Déployer sur ACI

### 4.1 — Créer le conteneur

```bash
az container create \
  --name $ACI_NAME \
  --resource-group $RESOURCE_GROUP \
  --image $ACR_LOGIN_SERVER/$IMAGE_NAME:$IMAGE_TAG \
  --registry-login-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --cpu 1 \
  --memory 1.5 \
  --ports 8080 \
  --dns-name-label $ACI_NAME-$RANDOM \
  --os-type Linux \
  --restart-policy Always
```

### 4.2 — Récupérer l'URL

```bash
ACI_FQDN=$(az container show \
  --name $ACI_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "ipAddress.fqdn" \
  --output tsv)

echo "══════════════════════════════════"
echo " URL : http://$ACI_FQDN:8080"
echo "══════════════════════════════════"
```

### 4.3 — Vérifier

```bash
# État
az container show \
  --name $ACI_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "{state:instanceView.state, fqdn:ipAddress.fqdn}" \
  --output table

# Logs
az container logs \
  --name $ACI_NAME \
  --resource-group $RESOURCE_GROUP

# Logs temps réel
az container attach \
  --name $ACI_NAME \
  --resource-group $RESOURCE_GROUP
```

---

## 5. Gestion du cycle de vie

### Redéployer une nouvelle version

```bash
IMAGE_TAG="v2"

az acr build \
  --registry $ACR_NAME \
  --image $IMAGE_NAME:$IMAGE_TAG \
  --file Dockerfile \
  .

az container delete \
  --name $ACI_NAME \
  --resource-group $RESOURCE_GROUP \
  --yes

az container create \
  --name $ACI_NAME \
  --resource-group $RESOURCE_GROUP \
  --image $ACR_LOGIN_SERVER/$IMAGE_NAME:$IMAGE_TAG \
  --registry-login-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --cpu 1 \
  --memory 1.5 \
  --ports 8080 \
  --dns-name-label $ACI_NAME-$RANDOM \
  --os-type Linux \
  --restart-policy Always
```

### Arrêter / Démarrer

```bash
az container stop --name $ACI_NAME --resource-group $RESOURCE_GROUP
az container start --name $ACI_NAME --resource-group $RESOURCE_GROUP
az container restart --name $ACI_NAME --resource-group $RESOURCE_GROUP
```

### Shell dans le conteneur

```bash
az container exec \
  --name $ACI_NAME \
  --resource-group $RESOURCE_GROUP \
  --exec-command "/bin/bash"
```

---

## 6. Nettoyage

```bash
az group delete --name $RESOURCE_GROUP --yes --no-wait
```

---

## Structure du projet

```
RazorTodo/
├── Dockerfile
├── .dockerignore
├── .gitignore
├── Program.cs                     # Razor Pages, pas de SignalR
├── RazorTodo.csproj
├── appsettings.json
├── Models/
│   └── TodoItem.cs
├── Services/
│   └── TodoService.cs             # CRUD en mémoire
├── Pages/
│   ├── _ViewImports.cshtml
│   ├── _ViewStart.cshtml
│   ├── Index.cshtml               # Vue TodoList
│   ├── Index.cshtml.cs            # PageModel avec handlers
│   └── Shared/
│       └── _Layout.cshtml         # Layout Bootstrap
├── wwwroot/css/
│   └── app.css
└── Properties/
    └── launchSettings.json
```
