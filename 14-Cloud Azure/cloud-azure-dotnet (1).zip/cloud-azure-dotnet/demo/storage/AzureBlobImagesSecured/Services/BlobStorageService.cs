using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using AzureBlobImages.Models;

namespace AzureBlobImages.Services;

public class BlobStorageService : IBlobStorageService
{
    private readonly BlobServiceClient _blobServiceClient;
    private readonly BlobContainerClient _containerClient;
    private readonly ILogger<BlobStorageService> _logger;
    private readonly int _sasTokenDurationMinutes;

    private static readonly HashSet<string> AllowedContentTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        "image/jpeg", "image/png", "image/gif", "image/webp", "image/bmp", "image/svg+xml"
    };

    private const long MaxFileSize = 10 * 1024 * 1024; // 10 Mo

    public BlobStorageService(
        BlobServiceClient blobServiceClient,
        IConfiguration configuration,
        ILogger<BlobStorageService> logger)
    {
        _blobServiceClient = blobServiceClient;
        _logger = logger;

        var containerName = configuration["AzureBlobStorage:ContainerName"] ?? "images";
        _sasTokenDurationMinutes = int.Parse(configuration["AzureBlobStorage:SasTokenDurationMinutes"] ?? "30");
        _containerClient = blobServiceClient.GetBlobContainerClient(containerName);
    }

    // ══════════════════════════ INIT ══════════════════════════

    public async Task InitializeAsync()
    {
        // Accès PRIVÉ : aucun accès anonyme
        await _containerClient.CreateIfNotExistsAsync(PublicAccessType.None);
        _logger.LogInformation("Conteneur '{Container}' initialisé (accès privé, SAS {Duration} min).",
            _containerClient.Name, _sasTokenDurationMinutes);
    }

    // ══════════════════════════ SAS TOKEN ══════════════════════════

    /// <summary>
    /// Génère une URL signée (SAS) en lecture seule avec expiration configurable
    /// </summary>
    private (string Uri, DateTimeOffset Expiration) GenerateSasUri(BlobClient blobClient)
    {
        if (!blobClient.CanGenerateSasUri)
            throw new InvalidOperationException(
                "Impossible de générer un SAS Token. " +
                "Vérifiez que la ConnectionString contient la clé du compte (AccountKey).");

        var expiration = DateTimeOffset.UtcNow.AddMinutes(_sasTokenDurationMinutes);

        var sasBuilder = new BlobSasBuilder
        {
            BlobContainerName = blobClient.BlobContainerName,
            BlobName = blobClient.Name,
            Resource = "b",             // b = blob individuel
            StartsOn = DateTimeOffset.UtcNow.AddMinutes(-5), // tolérance horloge
            ExpiresOn = expiration
        };

        // Permissions : lecture seule
        sasBuilder.SetPermissions(BlobSasPermissions.Read);

        var sasUri = blobClient.GenerateSasUri(sasBuilder).ToString();
        return (sasUri, expiration);
    }

    // ══════════════════════════ UPLOAD ══════════════════════════

    public async Task<UploadResultDto> UploadImageAsync(IFormFile file)
    {
        // Validation type MIME
        if (!AllowedContentTypes.Contains(file.ContentType))
        {
            return new UploadResultDto
            {
                Success = false,
                Message = $"Type non autorisé : {file.ContentType}. " +
                          $"Acceptés : {string.Join(", ", AllowedContentTypes)}"
            };
        }

        // Validation taille
        if (file.Length > MaxFileSize)
        {
            return new UploadResultDto
            {
                Success = false,
                Message = $"Fichier trop volumineux ({file.Length / (1024 * 1024)} Mo). Maximum : 10 Mo."
            };
        }

        try
        {
            // Nom unique pour éviter les collisions
            var extension = Path.GetExtension(file.FileName);
            var uniqueName = $"{Guid.NewGuid()}{extension}";
            var blobClient = _containerClient.GetBlobClient(uniqueName);

            // Upload avec headers et métadonnées
            await using var stream = file.OpenReadStream();
            await blobClient.UploadAsync(stream, new BlobUploadOptions
            {
                HttpHeaders = new BlobHttpHeaders { ContentType = file.ContentType },
                Metadata = new Dictionary<string, string>
                {
                    { "originalFileName", file.FileName },
                    { "uploadedAt", DateTimeOffset.UtcNow.ToString("o") }
                }
            });

            // Retourner une URL signée (pas l'URL publique)
            var (sasUri, _) = GenerateSasUri(blobClient);

            _logger.LogInformation("Image '{Original}' uploadée sous '{Blob}'.", file.FileName, uniqueName);

            return new UploadResultDto
            {
                Success = true,
                Message = "Image uploadée avec succès.",
                Uri = sasUri,
                FileName = uniqueName
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erreur upload '{FileName}'.", file.FileName);
            return new UploadResultDto
            {
                Success = false,
                Message = $"Erreur serveur : {ex.Message}"
            };
        }
    }

    // ══════════════════════════ LIST ══════════════════════════

    public async Task<List<BlobImageDto>> ListImagesAsync()
    {
        var images = new List<BlobImageDto>();

        await foreach (var blob in _containerClient.GetBlobsAsync(BlobTraits.Metadata))
        {
            var blobClient = _containerClient.GetBlobClient(blob.Name);

            // Générer un SAS Token pour chaque image
            var (sasUri, expiration) = GenerateSasUri(blobClient);

            images.Add(new BlobImageDto
            {
                Name = blob.Name,
                Uri = sasUri,
                ContentType = blob.Properties.ContentType ?? "unknown",
                Size = blob.Properties.ContentLength ?? 0,
                LastModified = blob.Properties.LastModified,
                SasExpiration = expiration
            });
        }

        _logger.LogInformation("{Count} image(s) listée(s) avec SAS Tokens ({Duration} min).",
            images.Count, _sasTokenDurationMinutes);

        return images.OrderByDescending(i => i.LastModified).ToList();
    }

    // ══════════════════════════ DELETE ══════════════════════════

    public async Task<DeleteResultDto> DeleteImageAsync(string fileName)
    {
        try
        {
            var blobClient = _containerClient.GetBlobClient(fileName);
            var response = await blobClient.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots);

            if (response.Value)
            {
                _logger.LogInformation("Image '{Blob}' supprimée.", fileName);
                return new DeleteResultDto { Success = true, Message = $"Image '{fileName}' supprimée avec succès." };
            }

            return new DeleteResultDto { Success = false, Message = $"Image '{fileName}' introuvable." };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erreur suppression '{Blob}'.", fileName);
            return new DeleteResultDto { Success = false, Message = $"Erreur serveur : {ex.Message}" };
        }
    }

    // ══════════════════════════ DOWNLOAD ══════════════════════════

    public async Task<(Stream? Content, string? ContentType)> DownloadImageAsync(string fileName)
    {
        try
        {
            var blobClient = _containerClient.GetBlobClient(fileName);
            var exists = await blobClient.ExistsAsync();
            if (!exists.Value) return (null, null);

            var properties = await blobClient.GetPropertiesAsync();
            var download = await blobClient.DownloadStreamingAsync();

            return (download.Value.Content, properties.Value.ContentType);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erreur téléchargement '{Blob}'.", fileName);
            return (null, null);
        }
    }
}
