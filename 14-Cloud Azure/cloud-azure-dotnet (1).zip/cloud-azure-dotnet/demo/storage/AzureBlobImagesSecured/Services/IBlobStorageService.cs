using AzureBlobImages.Models;

namespace AzureBlobImages.Services;

public interface IBlobStorageService
{
    Task InitializeAsync();
    Task<UploadResultDto> UploadImageAsync(IFormFile file);
    Task<List<BlobImageDto>> ListImagesAsync();
    Task<DeleteResultDto> DeleteImageAsync(string fileName);
    Task<(Stream? Content, string? ContentType)> DownloadImageAsync(string fileName);
}
