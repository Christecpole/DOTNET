using AzureBlobImages.Services;
using Microsoft.AspNetCore.Mvc;

namespace AzureBlobImages.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ImagesController : ControllerBase
{
    private readonly IBlobStorageService _blobService;

    public ImagesController(IBlobStorageService blobService)
    {
        _blobService = blobService;
    }

    /// <summary>
    /// Upload une image dans Azure Blob Storage (max 10 Mo)
    /// L'URL retournée est un SAS Token temporaire
    /// </summary>
    [HttpPost("upload")]
    [RequestSizeLimit(10 * 1024 * 1024)]
    public async Task<IActionResult> Upload(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new { message = "Aucun fichier fourni." });

        var result = await _blobService.UploadImageAsync(file);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>
    /// Upload plusieurs images en une requête (max 50 Mo total)
    /// </summary>
    [HttpPost("upload-multiple")]
    [RequestSizeLimit(50 * 1024 * 1024)]
    public async Task<IActionResult> UploadMultiple(List<IFormFile> files)
    {
        if (files == null || files.Count == 0)
            return BadRequest(new { message = "Aucun fichier fourni." });

        var results = new List<object>();
        foreach (var file in files)
        {
            results.Add(await _blobService.UploadImageAsync(file));
        }
        return Ok(results);
    }

    /// <summary>
    /// Liste toutes les images avec des URLs SAS temporaires
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> List()
    {
        var images = await _blobService.ListImagesAsync();
        return Ok(images);
    }

    /// <summary>
    /// Télécharge une image via le serveur (proxy sécurisé)
    /// </summary>
    [HttpGet("{fileName}")]
    public async Task<IActionResult> Download(string fileName)
    {
        var (content, contentType) = await _blobService.DownloadImageAsync(fileName);
        if (content == null)
            return NotFound(new { message = $"Image '{fileName}' introuvable." });

        return File(content, contentType ?? "application/octet-stream", fileName);
    }

    /// <summary>
    /// Supprime une image par son nom de blob
    /// </summary>
    [HttpDelete("{fileName}")]
    public async Task<IActionResult> Delete(string fileName)
    {
        var result = await _blobService.DeleteImageAsync(fileName);
        return result.Success ? Ok(result) : NotFound(result);
    }
}
