namespace AzureBlobImages.Models;

public class BlobImageDto
{
    public string Name { get; set; } = string.Empty;
    public string Uri { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public long Size { get; set; }
    public DateTimeOffset? LastModified { get; set; }
    public DateTimeOffset? SasExpiration { get; set; }
}

public class UploadResultDto
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public string? Uri { get; set; }
    public string? FileName { get; set; }
}

public class DeleteResultDto
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
}
