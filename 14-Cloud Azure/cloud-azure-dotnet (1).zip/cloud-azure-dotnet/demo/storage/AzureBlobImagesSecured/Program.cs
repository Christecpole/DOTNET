using Azure.Storage.Blobs;
using AzureBlobImages.Services;


var builder = WebApplication.CreateBuilder(args);

// ──────────────────────── Azure Blob Storage ────────────────────────
var connectionString = builder.Configuration["AzureBlobStorage:ConnectionString"]
    ?? throw new InvalidOperationException("AzureBlobStorage:ConnectionString manquante.");

builder.Services.AddSingleton(new BlobServiceClient(connectionString));
builder.Services.AddSingleton<BlobStorageService>();
builder.Services.AddSingleton<IBlobStorageService>(sp => sp.GetRequiredService<BlobStorageService>());

// ──────────────────────── API ────────────────────────
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "Azure Blob Images API (Sécurisé)",
        Version = "v1",
        Description = "API de gestion d'images avec Azure Blob Storage — Accès sécurisé via SAS Tokens"
    });
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

var app = builder.Build();

// ──────────────────────── Init conteneur (accès privé) ────────────────────────
using (var scope = app.Services.CreateScope())
{
    var blobService = scope.ServiceProvider.GetRequiredService<BlobStorageService>();
    await blobService.InitializeAsync();
}

// ──────────────────────── Pipeline ────────────────────────
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors();
app.UseHttpsRedirection();
app.MapControllers();

app.Run();
