# Azure Blob Images API — Sécurisé avec SAS Tokens

API .NET 8 de gestion d'images avec Azure Blob Storage SDK.  
Le conteneur est **privé** : les images sont accessibles uniquement via des **SAS Tokens** temporaires.

---

## Fonctionnalités

- **Upload** d'images (simple ou multiple) avec validation MIME et taille (10 Mo max)
- **Lister** toutes les images avec des URLs signées (SAS) temporaires
- **Télécharger** une image via proxy serveur sécurisé
- **Supprimer** une image par son nom de blob
- **Sécurité** : conteneur privé, accès via SAS Tokens avec expiration configurable

---

## 1. Commandes Azure CLI — Provisionner l'infrastructure

```bash
# ══════════════════════════════════════════════════════════
# Variables (à personnaliser)
# ══════════════════════════════════════════════════════════
RESOURCE_GROUP="rg-blob-images"
LOCATION="francecentral"
STORAGE_ACCOUNT="stblobimages$RANDOM"    # doit être unique, minuscules, 3-24 caractères
CONTAINER_NAME="images"

# ══════════════════════════════════════════════════════════
# Étape 1 : Créer le Resource Group
# ══════════════════════════════════════════════════════════
az group create \
  --name $RESOURCE_GROUP \
  --location $LOCATION

# ══════════════════════════════════════════════════════════
# Étape 2 : Créer le Storage Account
# ══════════════════════════════════════════════════════════
az storage account create \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --sku Standard_LRS \
  --kind StorageV2 \
  --access-tier Hot \
  --min-tls-version TLS1_2 \
  --allow-blob-public-access false

# ══════════════════════════════════════════════════════════
# Étape 3 : Récupérer la clé d'accès
# ══════════════════════════════════════════════════════════
STORAGE_KEY=$(az storage account keys list \
  --account-name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --query "[0].value" \
  --output tsv)

# ══════════════════════════════════════════════════════════
# Étape 4 : Créer le conteneur Blob (ACCÈS PRIVÉ)
# ══════════════════════════════════════════════════════════
az storage container create \
  --name $CONTAINER_NAME \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --public-access off

# ══════════════════════════════════════════════════════════
# Étape 5 : Récupérer la Connection String
# ══════════════════════════════════════════════════════════
CONNECTION_STRING=$(az storage account show-connection-string \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --query "connectionString" \
  --output tsv)

# ══════════════════════════════════════════════════════════
# Étape 6 : (Optionnel) Configurer les règles CORS
# ══════════════════════════════════════════════════════════
az storage cors add \
  --services b \
  --methods GET POST PUT DELETE \
  --origins "*" \
  --allowed-headers "*" \
  --exposed-headers "*" \
  --max-age 3600 \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY

# ══════════════════════════════════════════════════════════
# Étape 7 : (Optionnel) Activer le soft-delete (récupération)
# ══════════════════════════════════════════════════════════
az storage blob service-properties delete-policy update \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --enable true \
  --days-retained 7

# ══════════════════════════════════════════════════════════
# Résumé — Copier la ConnectionString dans appsettings.json
# ══════════════════════════════════════════════════════════
echo ""
echo "════════════════════════════════════════════════════"
echo " INFRASTRUCTURE CRÉÉE AVEC SUCCÈS"
echo "════════════════════════════════════════════════════"
echo " Resource Group  : $RESOURCE_GROUP"
echo " Storage Account : $STORAGE_ACCOUNT"
echo " Container       : $CONTAINER_NAME (accès privé)"
echo " Soft-delete     : activé (7 jours)"
echo ""
echo " Connection String (à copier dans appsettings.json) :"
echo " $CONNECTION_STRING"
echo "════════════════════════════════════════════════════"
```

### Vérifier la configuration

```bash
# Vérifier que l'accès public est bien désactivé
az storage account show \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --query "allowBlobPublicAccess"
# Doit retourner : false

# Vérifier le conteneur
az storage container show \
  --name $CONTAINER_NAME \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --query "properties.publicAccess"
# Doit retourner : null (privé)

# Lister les blobs (vide au départ)
az storage blob list \
  --container-name $CONTAINER_NAME \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --output table
```

### Nettoyage (supprimer toutes les ressources)

```bash
az group delete --name $RESOURCE_GROUP --yes --no-wait
```

---

## 2. Configuration du projet .NET

Copier la `ConnectionString` dans `appsettings.json` :

```json
{
  "AzureBlobStorage": {
    "ConnectionString": "COLLER_ICI_LA_CONNECTION_STRING",
    "ContainerName": "images",
    "SasTokenDurationMinutes": 30
  }
}
```

---

## 3. Lancement

```bash
dotnet restore
dotnet run
```

Swagger UI : `https://localhost:7100/swagger`

---

## 4. Endpoints

| Méthode  | URL                             | Description                          |
|----------|---------------------------------|--------------------------------------|
| `POST`   | `/api/images/upload`            | Upload une image (retourne SAS URL)  |
| `POST`   | `/api/images/upload-multiple`   | Upload plusieurs images              |
| `GET`    | `/api/images`                   | Liste les images (URLs SAS 30 min)   |
| `GET`    | `/api/images/{fileName}`        | Télécharge via proxy serveur         |
| `DELETE` | `/api/images/{fileName}`        | Supprime une image                   |

---

## 5. Exemples curl

```bash
# Upload
curl -X POST https://localhost:7100/api/images/upload \
  -F "file=@photo.jpg"

# Lister (les URIs contiennent le SAS token)
curl https://localhost:7100/api/images

# Télécharger via proxy (pas besoin de SAS)
curl -o image.jpg https://localhost:7100/api/images/abc-def-123.jpg

# Supprimer
curl -X DELETE https://localhost:7100/api/images/abc-def-123.jpg
```

**Upload une image**
- `POST` → `https://localhost:7100/api/images/upload`
- Body → form-data → Key : `file` (type File) → sélectionner l'image

**Upload plusieurs images**
- `POST` → `https://localhost:7100/api/images/upload-multiple`
- Body → form-data → Key : `files` (type File) → ajouter plusieurs lignes `files`

**Lister toutes les images**
- `GET` → `https://localhost:7100/api/images`

**Télécharger une image**
- `GET` → `https://localhost:7100/api/images/{blobName}`
- Remplacer `{blobName}` par le nom retourné dans l'upload (ex: `a1b2c3d4-e5f6-7890.jpg`)

**Supprimer une image**
- `DELETE` → `https://localhost:7100/api/images/{blobName}`

---

## 6. Sécurité — Comment ça marche

```
┌──────────┐     POST /upload      ┌──────────────┐     SDK Azure      ┌─────────────────┐
│  Client   │ ──────────────────▶  │  API .NET 8  │ ────────────────▶  │  Azure Blob     │
│           │                      │              │                     │  Storage        │
│           │  ◀─── SAS URL ────── │  Génère SAS  │                     │  (privé)        │
│           │                      │  Token       │                     │                 │
│           │     GET /images      │              │     list blobs      │                 │
│           │ ──────────────────▶  │              │ ────────────────▶  │                 │
│           │  ◀─ SAS URLs (30m) ─ │              │                     │                 │
│           │                      │              │                     │                 │
│           │  GET image via SAS   │              │                     │                 │
│           │ ─────────────────────────────────────────────────────────▶│                 │
│           │  ◀──────────── image data (si SAS valide) ──────────────│                 │
└──────────┘                      └──────────────┘                     └─────────────────┘
```

- Le conteneur est **privé** (`--public-access off` + `PublicAccessType.None`)
- L'accès public est **désactivé** au niveau du compte (`--allow-blob-public-access false`)
- Chaque URL d'image contient un **SAS Token** (Shared Access Signature) en lecture seule
- Les tokens **expirent après 30 minutes** (configurable via `SasTokenDurationMinutes`)
- Le **soft-delete** permet de récupérer les images supprimées pendant 7 jours
- TLS 1.2 minimum imposé

---

## Architecture

```
AzureBlobImages/
├── Program.cs                          # DI, Swagger, Init conteneur privé
├── AzureBlobImages.csproj              # Azure.Storage.Blobs + Swashbuckle
├── appsettings.json                    # ConnectionString + SAS duration
├── Controllers/
│   └── ImagesController.cs             # 5 endpoints REST
├── Services/
│   ├── IBlobStorageService.cs          # Interface
│   └── BlobStorageService.cs           # Upload, List, Delete + SAS Token
├── Models/
│   └── BlobImageDto.cs                 # DTOs avec SasExpiration
└── Properties/
    └── launchSettings.json
```
