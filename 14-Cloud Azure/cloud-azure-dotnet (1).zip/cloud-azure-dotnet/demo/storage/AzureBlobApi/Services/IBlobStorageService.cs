using AzureBlobApi.Models;

namespace AzureBlobApi.Services;

public interface IBlobStorageService
{
    Task<BlobInfo> UploadAsync(IFormFile file);
    Task<(Stream Content, string ContentType)> DownloadAsync(string fileName);
    Task<IEnumerable<BlobInfo>> ListAsync();
    Task<bool> DeleteAsync(string fileName);
    Task<bool> ExistsAsync(string fileName);
}
