using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using AzureBlobApi.Models;

namespace AzureBlobApi.Services;

public class BlobStorageService : IBlobStorageService
{
    private readonly BlobContainerClient _containerClient;
    private readonly ILogger<BlobStorageService> _logger;

    public BlobStorageService(BlobServiceClient blobServiceClient, BlobStorageSettings settings, ILogger<BlobStorageService> logger)
    {
        _logger = logger;

        // Récupère le client du container à partir du nom configuré dans appsettings
        _containerClient = blobServiceClient.GetBlobContainerClient(settings.ContainerName);

        // Crée le container s'il n'existe pas encore, sans accès public
        _containerClient.CreateIfNotExists(PublicAccessType.None);

        _logger.LogInformation("BlobStorageService initialized. Container: {ContainerName}", settings.ContainerName);
    }

    public async Task<BlobInfo> UploadAsync(IFormFile file)
    {
        // Génère un nom unique pour éviter les collisions entre fichiers
        var fileName = $"{Guid.NewGuid()}_{Path.GetFileName(file.FileName)}";
        var blobClient = _containerClient.GetBlobClient(fileName);

        // Conserve le Content-Type original du fichier (ex: image/png, application/pdf)
        var blobHttpHeaders = new BlobHttpHeaders
        {
            ContentType = file.ContentType
        };

        // Upload le flux du fichier vers Azure Blob Storage
        using var stream = file.OpenReadStream();
        await blobClient.UploadAsync(stream, new BlobUploadOptions { HttpHeaders = blobHttpHeaders });

        _logger.LogInformation("Uploaded blob: {FileName}", fileName);

        // Retourne les métadonnées du blob uploadé
        return new BlobInfo
        {
            Name = fileName,
            Uri = blobClient.Uri.ToString(),
            Size = file.Length,
            ContentType = file.ContentType,
            LastModified = DateTimeOffset.UtcNow
        };
    }

    public async Task<(Stream Content, string ContentType)> DownloadAsync(string fileName)
    {
        var blobClient = _containerClient.GetBlobClient(fileName);

        // Vérifie que le blob existe avant de tenter le téléchargement
        if (!await blobClient.ExistsAsync())
            throw new FileNotFoundException($"Blob '{fileName}' introuvable.");

        var response = await blobClient.DownloadAsync();

        // Utilise le Content-Type stocké, ou un type binaire générique par défaut
        var contentType = response.Value.Details.ContentType ?? "application/octet-stream";

        _logger.LogInformation("Downloaded blob: {FileName}", fileName);

        return (response.Value.Content, contentType);
    }

    public async Task<IEnumerable<BlobInfo>> ListAsync()
    {
        var blobs = new List<BlobInfo>();

        // Parcourt tous les blobs du container de façon asynchrone
        await foreach (var blobItem in _containerClient.GetBlobsAsync())
        {
            var blobClient = _containerClient.GetBlobClient(blobItem.Name);
            blobs.Add(new BlobInfo
            {
                Name = blobItem.Name,
                Uri = blobClient.Uri.ToString(),
                Size = blobItem.Properties.ContentLength,
                ContentType = blobItem.Properties.ContentType,
                LastModified = blobItem.Properties.LastModified
            });
        }

        return blobs;
    }

    public async Task<bool> DeleteAsync(string fileName)
    {
        var blobClient = _containerClient.GetBlobClient(fileName);

        // Supprime le blob s'il existe, sans lever d'exception s'il est absent
        var result = await blobClient.DeleteIfExistsAsync();

        if (result.Value)
            _logger.LogInformation("Deleted blob: {FileName}", fileName);
        else
            _logger.LogWarning("Blob not found for deletion: {FileName}", fileName);

        return result.Value;
    }

    public async Task<bool> ExistsAsync(string fileName)
    {
        var blobClient = _containerClient.GetBlobClient(fileName);

        // Retourne true si le blob existe dans le container, false sinon
        var result = await blobClient.ExistsAsync();
        return result.Value;
    }
}