using Azure.Storage.Blobs;
using AzureBlobApi.Models;
using AzureBlobApi.Services;

var builder = WebApplication.CreateBuilder(args);

// ─── Configuration Azure Storage ───────────────────────────────────────────
var storageSettings = builder.Configuration
    .GetSection("AzureStorage")
    .Get<BlobStorageSettings>()
    ?? throw new InvalidOperationException("La section 'AzureStorage' est manquante dans appsettings.json");

builder.Services.AddSingleton(storageSettings);
builder.Services.AddSingleton(new BlobServiceClient(storageSettings.ConnectionString));

// ─── Services ───────────────────────────────────────────────────────────────
builder.Services.AddScoped<IBlobStorageService, BlobStorageService>();

// ─── Controllers + Swagger ──────────────────────────────────────────────────
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new()
    {
        Title = "Azure Blob Storage API",
        Version = "v1",
        Description = "API de démonstration pour Azure Blob Storage"
    });
});

var app = builder.Build();

// ─── Middleware ──────────────────────────────────────────────────────────────
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Azure Blob Storage API v1");
        c.RoutePrefix = string.Empty; // Swagger à la racine
    });
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
