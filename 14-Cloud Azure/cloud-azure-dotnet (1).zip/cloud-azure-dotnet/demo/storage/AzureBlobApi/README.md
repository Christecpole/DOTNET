# 🗂️ Azure Blob Storage API

## Table of Contents

<details>
<summary>Contents</summary>

1. [📋 Prérequis](#-prérequis)
1. [☁️ Étape 1 — Créer les ressources Azure (Interface Graphique)](#-étape-1--créer-les-ressources-azure-interface-graphique)
   1. [1.1 Se connecter au portail Azure](#11-se-connecter-au-portail-azure)
   1. [1.2 Créer un Resource Group](#12-créer-un-resource-group)
   1. [1.3 Créer un Storage Account](#13-créer-un-storage-account)
   1. [1.4 Créer un Container Blob](#14-créer-un-container-blob)
   1. [1.5 Récupérer la Connection String](#15-récupérer-la-connection-string)
1. [⌨️ Étape 1 (alternative) — Créer les ressources Azure (Azure CLI)](#-étape-1-alternative--créer-les-ressources-azure-azure-cli)
1. [🛠️ Étape 2 — Configurer le projet .NET](#-étape-2--configurer-le-projet-net)
   1. [2.1 Cloner / extraire le projet](#21-cloner--extraire-le-projet)
   1. [2.2 Restaurer les packages](#22-restaurer-les-packages)
   1. [2.3 Configurer la Connection String](#23-configurer-la-connection-string)
1. [🚀 Étape 3 — Lancer le projet](#-étape-3--lancer-le-projet)
1. [📡 Endpoints disponibles](#-endpoints-disponibles)
1. [🧪 Tester avec curl](#-tester-avec-curl)
1. [🗂️ Structure du projet](#-structure-du-projet)
1. [🔒 Sécurité](#-sécurité)
1. [🧹 Supprimer les ressources Azure](#-supprimer-les-ressources-azure)
1. [📦 Packages NuGet utilisés](#-packages-nuget-utilisés)
1. [🔗 Ressources utiles](#-ressources-utiles)
1. [🏗️ Créer le projet from scratch](#-créer-le-projet-from-scratch)

</details>

API REST en **.NET 8** pour gérer des fichiers sur **Azure Blob Storage** (upload, download, liste, suppression).

---

## 📋 Prérequis

| Outil | Version | Lien |
|---|---|---|
| .NET SDK | 8.0+ | https://dotnet.microsoft.com/download |
| Azure CLI | Dernière | https://learn.microsoft.com/cli/azure/install-azure-cli |
| Compte Azure | Actif | https://portal.azure.com |

---

## ☁️ Étape 1 — Créer les ressources Azure (Interface Graphique)

### 1.1 Se connecter au portail Azure

Rends-toi sur **https://portal.azure.com** et connecte-toi avec ton compte.

---

### 1.2 Créer un Resource Group

1. Dans la barre de recherche, tape **"Resource groups"** → **+ Create**
2. Remplis les champs :
   - **Subscription** : ta souscription
   - **Resource group** : `rg-blobstorage-demo`
   - **Region** : `France Central`
3. Clique sur **Review + create** → **Create**

---

### 1.3 Créer un Storage Account

1. Dans la barre de recherche, tape **"Storage accounts"** → **+ Create**

**Onglet Basics**

Remplis les champs :
- **Subscription** : ta souscription
- **Resource group** : `rg-blobstorage-demo`
- **Storage account name** : `stblobdemo2itech` *(unique globalement, minuscules et chiffres uniquement)*
- **Region** : `France Central`
- **Performance** : `Standard`
- **Redundancy** : `LRS (Locally-redundant storage)`

**Onglet Advanced**

- **Allow enabling anonymous access on individual containers** : `Décoché` *(sécurité)*
- **Enable storage account key access** : `Coché` *(nécessaire pour la Connection String)*
- Laisser le reste par défaut

**Onglet Networking**

- **Network access** : `Enable public access from all networks` *(pour la démo)*
- Laisser le reste par défaut

**Onglet Data protection**

- Laisser tout par défaut

**Onglet Encryption**

- Laisser tout par défaut

2. Clique sur **Review + create**
3. Vérifie le résumé puis clique sur **Create**
4. Attends le message **"Your deployment is complete"** puis clique sur **Go to resource**

---

### 1.4 Créer un Container Blob

1. Ouvre ton Storage Account fraîchement créé
2. Dans le menu gauche → **Containers** (section *Data storage*)
3. Clique sur **+ Container**
4. Remplis :
   - **Name** : `uploads`
   - **Public access level** : `Private (no anonymous access)`
5. Clique sur **Create**

---

### 1.5 Récupérer la Connection String

1. Dans ton Storage Account, menu gauche → **Access keys** (section *Security + networking*)
2. Clique sur **Show keys** (ou **Show** à côté de la clé)
3. Copie la valeur du champ **Connection string** (key1 ou key2, peu importe)

```
DefaultEndpointsProtocol=https;AccountName=stblobdemo2itech;AccountKey=XXXX...;EndpointSuffix=core.windows.net
```

📋 **Copie cette chaîne**, elle sera utilisée à l'étape 2.3.

> ⚠️ Ne partage jamais cette clé publiquement, elle donne un accès total à ton Storage Account.

---

## ⌨️ Étape 1 (alternative) — Créer les ressources Azure (Azure CLI)

### Se connecter à Azure

```bash
az login
```

### Créer un Resource Group

```bash
az group create \
  --name rg-blobstorage-demo \
  --location francecentral
```

### Créer un Storage Account

```bash
az storage account create \
  --name stblobdemo2itech \
  --resource-group rg-blobstorage-demo \
  --location francecentral \
  --sku Standard_LRS \
  --kind StorageV2
```

### Créer un Container Blob

```bash
az storage container create \
  --name uploads \
  --account-name stblobdemo2itech \
  --public-access off
```

### Récupérer la Connection String

```bash
az storage account show-connection-string \
  --name stblobdemo2itech \
  --resource-group rg-blobstorage-demo \
  --output tsv
```

📋 **Copie cette chaîne**, elle sera utilisée à l'étape suivante.

---

## 🛠️ Étape 2 — Configurer le projet .NET

### 2.1 Cloner / extraire le projet

```bash
cd AzureBlobStorageApi/src/AzureBlobApi
```

### 2.2 Restaurer les packages

```bash
dotnet restore
```

### 2.3 Configurer la Connection String

**Option A — appsettings.Development.json** *(simple, ne pas commiter)*

Ouvre `appsettings.Development.json` et remplace :

```json
{
  "AzureStorage": {
    "ConnectionString": "COLLE_TA_CONNECTION_STRING_ICI",
    "ContainerName": "uploads"
  }
}
```

**Option B — Variables d'environnement**

```bash
export AzureStorage__ConnectionString="ta-connection-string"
export AzureStorage__ContainerName="uploads"
```

---

## 🚀 Étape 3 — Lancer le projet

```bash
dotnet run
```

L'API démarre sur `https://localhost:5001` et `http://localhost:5000`.

Swagger UI disponible à : **http://localhost:5000**

---

## 📡 Endpoints disponibles

| Méthode | Route | Description |
|---|---|---|
| `GET` | `/api/blob` | Liste tous les fichiers |
| `POST` | `/api/blob/upload` | Upload un fichier |
| `GET` | `/api/blob/download/{fileName}` | Télécharge un fichier |
| `GET` | `/api/blob/exists/{fileName}` | Vérifie si un fichier existe |
| `DELETE` | `/api/blob/{fileName}` | Supprime un fichier |

---

## 🧪 Tester avec curl

### Upload d'un fichier

```bash
curl -X POST https://localhost:5001/api/blob/upload \
  -F "file=@/chemin/vers/mon-fichier.pdf" \
  -k
```

Réponse :
```json
{
  "name": "3f2a1b4c_mon-fichier.pdf",
  "uri": "https://stblobdemo2itech.blob.core.windows.net/uploads/3f2a1b4c_mon-fichier.pdf",
  "size": 102400,
  "contentType": "application/pdf",
  "lastModified": "2024-01-15T10:30:00Z"
}
```

### Liste des fichiers

```bash
curl https://localhost:5001/api/blob -k
```

### Téléchargement

```bash
curl https://localhost:5001/api/blob/download/3f2a1b4c_mon-fichier.pdf \
  -o fichier-telecharge.pdf -k
```

### Suppression

```bash
curl -X DELETE https://localhost:5001/api/blob/3f2a1b4c_mon-fichier.pdf -k
```

---

## 🗂️ Structure du projet

```
AzureBlobStorageApi/
└── src/
    └── AzureBlobApi/
        ├── Controllers/
        │   └── BlobController.cs       # Endpoints REST
        ├── Models/
        │   ├── BlobInfo.cs             # Modèle de réponse
        │   └── BlobStorageSettings.cs  # Configuration typée
        ├── Services/
        │   ├── IBlobStorageService.cs  # Interface
        │   └── BlobStorageService.cs  # Implémentation Azure SDK
        ├── Program.cs                  # Bootstrap + DI
        ├── appsettings.json
        └── appsettings.Development.json
```

---

## 🔒 Sécurité

| Pratique | Détail |
|---|---|
| ✅ Ne jamais commiter les clés | Utilise `appsettings.Development.json` (hors Git) ou variables d'environnement |
| ✅ Container privé | `PublicAccessType.None` par défaut |
| ✅ Limite de taille | 50 MB max par fichier |
| ✅ GUID préfixé | Chaque fichier reçoit un nom unique pour éviter les collisions |
| ⚠️ En production | Utiliser **Managed Identity** à la place de la Connection String |

---

## 🧹 Supprimer les ressources Azure

Quand tu n'en as plus besoin :

```bash
az group delete --name rg-blobstorage-demo --yes --no-wait
```

---

## 📦 Packages NuGet utilisés

| Package | Usage |
|---|---|
| `Azure.Storage.Blobs` | SDK officiel Azure Blob Storage |
| `Swashbuckle.AspNetCore` | Swagger / OpenAPI |

---

## 🔗 Ressources utiles

- [Documentation Azure Blob Storage](https://learn.microsoft.com/azure/storage/blobs/)
- [SDK .NET Azure.Storage.Blobs](https://learn.microsoft.com/dotnet/api/azure.storage.blobs)
- [Azure CLI - Storage](https://learn.microsoft.com/cli/azure/storage)

---

## 🏗️ Créer le projet from scratch

Voici toutes les étapes pour créer le projet en ligne de commande :

### 1. Créer la structure du projet

```bash
# Créer le dossier racine
mkdir AzureBlobStorageApi && cd AzureBlobStorageApi

# Créer la solution
dotnet new sln -n AzureBlobStorageApi

# Créer le projet Web API
dotnet new webapi -n AzureBlobApi -o src/AzureBlobApi --no-openapi

# Ajouter le projet à la solution
dotnet sln add src/AzureBlobApi/AzureBlobApi.csproj
```

### 2. Ajouter les packages NuGet

```bash
cd src/AzureBlobApi

dotnet add package Azure.Storage.Blobs
dotnet add package Swashbuckle.AspNetCore
```

### 3. Créer les dossiers

```bash
mkdir Controllers Services Models
```

### 4. Supprimer les fichiers générés inutiles

```bash
rm Controllers/WeatherForecastController.cs
rm WeatherForecast.cs
```

### 5. Vérifier la structure finale

```bash
cd ../..
find . -type f | sort
```

Tu dois obtenir :

```
./AzureBlobStorageApi.sln
./src/AzureBlobApi/AzureBlobApi.csproj
./src/AzureBlobApi/appsettings.json
./src/AzureBlobApi/appsettings.Development.json
./src/AzureBlobApi/Program.cs
./src/AzureBlobApi/Controllers/        ← vide, prêt pour BlobController.cs
./src/AzureBlobApi/Services/           ← vide, prêt pour les services
./src/AzureBlobApi/Models/             ← vide, prêt pour les modèles
```

### 6. Build et lancement

```bash
# Vérifier que tout compile
dotnet build

# Lancer le projet
dotnet run
```

### Récapitulatif en one-shot

```bash
mkdir AzureBlobStorageApi && cd AzureBlobStorageApi
dotnet new sln -n AzureBlobStorageApi
dotnet new webapi -n AzureBlobApi -o src/AzureBlobApi --no-openapi
dotnet sln add src/AzureBlobApi/AzureBlobApi.csproj
cd src/AzureBlobApi
dotnet add package Azure.Storage.Blobs
dotnet add package Swashbuckle.AspNetCore
mkdir Controllers Services Models
rm Controllers/WeatherForecastController.cs WeatherForecast.cs
```

Ensuite tu n'as plus qu'à copier les fichiers `.cs` du projet dans les bons dossiers et faire `dotnet run`. 🚀
