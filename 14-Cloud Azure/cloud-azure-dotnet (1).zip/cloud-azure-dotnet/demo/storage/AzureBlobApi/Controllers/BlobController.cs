using AzureBlobApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace AzureBlobApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class BlobController : ControllerBase
{
    private readonly IBlobStorageService _blobService;
    private readonly ILogger<BlobController> _logger;

    public BlobController(IBlobStorageService blobService, ILogger<BlobController> logger)
    {
        _blobService = blobService;
        _logger = logger;
    }


    [HttpGet]
    public async Task<IActionResult> List()
    {
        var blobs = await _blobService.ListAsync();
        return Ok(blobs);
    }

 
    [HttpPost("upload")]
    [RequestSizeLimit(50 * 1024 * 1024)] // 50 MB max
    public async Task<IActionResult> Upload(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new { error = "Aucun fichier fourni ou fichier vide." });

        var blobInfo = await _blobService.UploadAsync(file);
        return Created(blobInfo.Uri, blobInfo);
    }

 
    [HttpGet("download/{fileName}")]
    public async Task<IActionResult> Download(string fileName)
    {
        try
        {
            var (content, contentType) = await _blobService.DownloadAsync(fileName);
            return File(content, contentType, fileName);
        }
        catch (FileNotFoundException ex)
        {
            return NotFound(new { error = ex.Message });
        }
    }

   
    [HttpGet("exists/{fileName}")]
    public async Task<IActionResult> Exists(string fileName)
    {
        var exists = await _blobService.ExistsAsync(fileName);
        return Ok(new { fileName, exists });
    }


    [HttpDelete("{fileName}")]
    public async Task<IActionResult> Delete(string fileName)
    {
        var deleted = await _blobService.DeleteAsync(fileName);

        if (!deleted)
            return NotFound(new { error = $"Blob '{fileName}' introuvable." });

        return Ok(new { message = $"Blob '{fileName}' supprimé avec succès." });
    }
}