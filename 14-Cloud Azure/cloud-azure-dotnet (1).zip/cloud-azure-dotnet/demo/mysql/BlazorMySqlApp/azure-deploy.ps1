# ════════════════════════════════════════════════════════════════
#  azure-deploy.ps1 — Provisionnement Azure avec ACI
#  Ressources : Resource Group, MySQL Flexible Server, ACR, ACI
# ════════════════════════════════════════════════════════════════
$ErrorActionPreference = "Stop"

# ── Variables (à adapter) ────────────────────────────────────────
$RESOURCE_GROUP  = "rg-blazormysql"
$LOCATION        = "francecentral"
$MYSQL_SERVER    = "mysql-blazor-$(Get-Random -Maximum 99999)"
$MYSQL_ADMIN     = "blazoradmin"
$MYSQL_PASSWORD  = "P@ssw0rd$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())!"
$MYSQL_DB        = "blazordb"
$MYSQL_SKU       = "Standard_B1ms"
$MYSQL_TIER      = "Burstable"
$ACR_NAME        = "acrblazor$(Get-Random -Maximum 99999)"
$CONTAINER_NAME  = "blazormysqlapp"
$DNS_LABEL       = "blazormysql-$(Get-Random -Maximum 99999)"

# ── 1. Connexion ─────────────────────────────────────────────────
Write-Host "🔐 Connexion Azure..." -ForegroundColor Cyan
az login --output none

# ── 2. Resource Group ────────────────────────────────────────────
Write-Host "📁 Resource Group [$RESOURCE_GROUP]..." -ForegroundColor Cyan
az group create `
  --name     $RESOURCE_GROUP `
  --location $LOCATION `
  --output   none

# ── 3. MySQL Flexible Server ─────────────────────────────────────
Write-Host "🗄️  MySQL Flexible Server [$MYSQL_SERVER] (⏳ ~5 min)..." -ForegroundColor Cyan
az mysql flexible-server create `
  --resource-group   $RESOURCE_GROUP `
  --name             $MYSQL_SERVER `
  --location         $LOCATION `
  --admin-user       $MYSQL_ADMIN `
  --admin-password   $MYSQL_PASSWORD `
  --sku-name         $MYSQL_SKU `
  --tier             $MYSQL_TIER `
  --version          "8.0.21" `
  --storage-size     32 `
  --backup-retention 7 `
  --high-availability Disabled `
  --output none

az mysql flexible-server db create `
  --resource-group $RESOURCE_GROUP `
  --server-name    $MYSQL_SERVER `
  --database-name  $MYSQL_DB `
  --output         none

# ACI utilise une IP publique sortante
az mysql flexible-server firewall-rule create `
  --resource-group   $RESOURCE_GROUP `
  --name             $MYSQL_SERVER `
  --rule-name        "AllowAllAzureIPs" `
  --start-ip-address 0.0.0.0 `
  --end-ip-address   0.0.0.0 `
  --output           none

$MYSQL_HOST = az mysql flexible-server show `
  --resource-group $RESOURCE_GROUP `
  --name           $MYSQL_SERVER `
  --query          "fullyQualifiedDomainName" -o tsv

Write-Host "✅ MySQL : $MYSQL_HOST" -ForegroundColor Green

# ── 4. Azure Container Registry ──────────────────────────────────
Write-Host "📦 Container Registry [$ACR_NAME]..." -ForegroundColor Cyan
az acr create `
  --resource-group $RESOURCE_GROUP `
  --name           $ACR_NAME `
  --sku            Basic `
  --admin-enabled  true `
  --output         none

$ACR_SERVER   = az acr show --name $ACR_NAME --query "loginServer" -o tsv
$ACR_USER     = az acr credential show --name $ACR_NAME --query "username" -o tsv
$ACR_PASSWORD = az acr credential show --name $ACR_NAME --query "passwords[0].value" -o tsv

Write-Host "🐳 Build & Push de l'image..." -ForegroundColor Cyan
az acr login --name $ACR_NAME
docker build -t "$ACR_SERVER/blazormysqlapp:latest" .
docker push "$ACR_SERVER/blazormysqlapp:latest"

# ── 5. Azure Container Instances ─────────────────────────────────
Write-Host "🚀 Déploiement ACI [$CONTAINER_NAME]..." -ForegroundColor Cyan

$CONNECTION_STRING = "Server=${MYSQL_HOST};Port=3306;Database=${MYSQL_DB};User Id=${MYSQL_ADMIN};Password=${MYSQL_PASSWORD};SslMode=Required;"

az container create `
  --resource-group        $RESOURCE_GROUP `
  --name                  $CONTAINER_NAME `
  --image                 "$ACR_SERVER/blazormysqlapp:latest" `
  --registry-login-server $ACR_SERVER `
  --registry-username     $ACR_USER `
  --registry-password     $ACR_PASSWORD `
  --cpu                   1 `
  --memory                1.5 `
  --ports                 8080 `
  --protocol              TCP `
  --os-type               Linux `
  --dns-name-label        $DNS_LABEL `
  --location              $LOCATION `
  --environment-variables `
      ASPNETCORE_ENVIRONMENT=Production `
      WEBSITES_PORT=8080 `
  --secure-environment-variables `
      "ConnectionStrings__DefaultConnection=$CONNECTION_STRING" `
  --restart-policy        Always `
  --output                none

$APP_URL = az container show `
  --resource-group $RESOURCE_GROUP `
  --name           $CONTAINER_NAME `
  --query          "ipAddress.fqdn" -o tsv

Write-Host ""
Write-Host "══════════════════════════════════════════════" -ForegroundColor Green
Write-Host "✅ Déploiement terminé !"                       -ForegroundColor Green
Write-Host ""
Write-Host "  🌐 Application : http://${APP_URL}:8080"      -ForegroundColor Yellow
Write-Host "  🗄️  MySQL       : $MYSQL_HOST"                -ForegroundColor Yellow
Write-Host "  📦 ACR         : $ACR_SERVER"                 -ForegroundColor Yellow
Write-Host "  📁 Groupe      : $RESOURCE_GROUP"             -ForegroundColor Yellow
Write-Host "══════════════════════════════════════════════" -ForegroundColor Green
