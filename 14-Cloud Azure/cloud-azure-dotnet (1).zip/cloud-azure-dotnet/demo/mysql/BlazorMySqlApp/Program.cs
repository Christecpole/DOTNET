using BlazorMySqlApp.Data;
using Microsoft.EntityFrameworkCore;
using BlazorMySqlApp;

var builder = WebApplication.CreateBuilder(args);

// ── Razor Components + Blazor Server interactif ────────────────────────────
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// ── Entity Framework Core → MySQL (Pomelo) ────────────────────────────────
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

builder.Services.AddDbContextFactory<AppDbContext>(options =>
    options.UseMySql(connectionString, new MySqlServerVersion(new Version(8, 0, 21)),
        mysql => mysql.EnableRetryOnFailure(maxRetryCount: 5, maxRetryDelay: TimeSpan.FromSeconds(10), errorNumbersToAdd: null)));

// ── Services métier ───────────────────────────────────────────────────────
builder.Services.AddScoped<ProductService>();

var app = builder.Build();

// ── Migration automatique au démarrage ────────────────────────────────────
using (var scope = app.Services.CreateScope())
{
    var dbFactory = scope.ServiceProvider.GetRequiredService<IDbContextFactory<AppDbContext>>();
    using var db = dbFactory.CreateDbContext();
    db.Database.Migrate();
}

// ── Pipeline HTTP ─────────────────────────────────────────────────────────
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
   .AddInteractiveServerRenderMode();

app.Run();
