using BlazorMySqlApp.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorMySqlApp.Data;

public class ProductService(IDbContextFactory<AppDbContext> dbFactory)
{
    public async Task<List<Product>> GetAllAsync()
    {
        await using var db = await dbFactory.CreateDbContextAsync();
        return await db.Products.AsNoTracking().OrderBy(p => p.Name).ToListAsync();
    }

    public async Task<Product?> GetByIdAsync(int id)
    {
        await using var db = await dbFactory.CreateDbContextAsync();
        return await db.Products.FindAsync(id);
    }

    public async Task<List<Product>> SearchAsync(string term)
    {
        await using var db = await dbFactory.CreateDbContextAsync();
        return await db.Products.AsNoTracking()
            .Where(p => p.Name.Contains(term) || (p.Description != null && p.Description.Contains(term)))
            .OrderBy(p => p.Name)
            .ToListAsync();
    }

    public async Task<Product> CreateAsync(Product product)
    {
        await using var db = await dbFactory.CreateDbContextAsync();
        product.CreatedAt = DateTime.UtcNow;
        db.Products.Add(product);
        await db.SaveChangesAsync();
        return product;
    }

    public async Task<bool> UpdateAsync(Product product)
    {
        await using var db = await dbFactory.CreateDbContextAsync();
        product.UpdatedAt = DateTime.UtcNow;
        db.Products.Update(product);
        return await db.SaveChangesAsync() > 0;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        await using var db = await dbFactory.CreateDbContextAsync();
        return await db.Products.Where(p => p.Id == id).ExecuteDeleteAsync() > 0;
    }

    public async Task<(int count, decimal totalValue)> GetStatsAsync()
    {
        await using var db = await dbFactory.CreateDbContextAsync();
        var count = await db.Products.CountAsync();
        var total = await db.Products.SumAsync(p => p.Price * p.Stock);
        return (count, total);
    }
}
