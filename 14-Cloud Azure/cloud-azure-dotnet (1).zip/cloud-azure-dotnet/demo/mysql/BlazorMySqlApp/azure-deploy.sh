#!/bin/bash
# ════════════════════════════════════════════════════════════════
#  azure-deploy.sh — Provisionnement Azure avec ACI
#  Ressources : Resource Group, MySQL Flexible Server, ACR, ACI
# ════════════════════════════════════════════════════════════════
set -e

# ── Variables (à adapter) ────────────────────────────────────────
RESOURCE_GROUP="rg-blazormysql"
LOCATION="francecentral"
MYSQL_SERVER="mysql-blazor-$RANDOM"
MYSQL_ADMIN="blazoradmin"
MYSQL_PASSWORD="P@ssw0rd$(date +%s)!"
MYSQL_DB="blazordb"
MYSQL_SKU="Standard_B1ms"
MYSQL_TIER="Burstable"
ACR_NAME="acrblazor$RANDOM"
CONTAINER_NAME="blazormysqlapp"
DNS_LABEL="blazormysql-$RANDOM"

# ── 1. Connexion ─────────────────────────────────────────────────
echo "🔐 Connexion Azure..."
az login --output none

# ── 2. Resource Group ────────────────────────────────────────────
echo "📁 Resource Group [$RESOURCE_GROUP]..."
az group create --name "$RESOURCE_GROUP" --location "$LOCATION" --output none

# ── 3. MySQL Flexible Server ─────────────────────────────────────
echo "🗄️  MySQL Flexible Server [$MYSQL_SERVER] (⏳ ~5 min)..."
az mysql flexible-server create \
  --resource-group   "$RESOURCE_GROUP" \
  --name             "$MYSQL_SERVER" \
  --location         "$LOCATION" \
  --admin-user       "$MYSQL_ADMIN" \
  --admin-password   "$MYSQL_PASSWORD" \
  --sku-name         "$MYSQL_SKU" \
  --tier             "$MYSQL_TIER" \
  --version          "8.0.21" \
  --storage-size     32 \
  --backup-retention 7 \
  --high-availability Disabled \
  --output none

az mysql flexible-server db create \
  --resource-group "$RESOURCE_GROUP" \
  --server-name    "$MYSQL_SERVER" \
  --database-name  "$MYSQL_DB" \
  --output none

# ACI utilise une IP publique sortante
az mysql flexible-server firewall-rule create \
  --resource-group   "$RESOURCE_GROUP" \
  --name             "$MYSQL_SERVER" \
  --rule-name        "AllowAllAzureIPs" \
  --start-ip-address 0.0.0.0 \
  --end-ip-address   0.0.0.0 \
  --output none

MYSQL_HOST=$(az mysql flexible-server show \
  --resource-group "$RESOURCE_GROUP" \
  --name           "$MYSQL_SERVER" \
  --query          "fullyQualifiedDomainName" -o tsv)
echo "✅ MySQL : $MYSQL_HOST"

# ── 4. Azure Container Registry ──────────────────────────────────
echo "📦 Container Registry [$ACR_NAME]..."
az acr create \
  --resource-group "$RESOURCE_GROUP" \
  --name           "$ACR_NAME" \
  --sku            Basic \
  --admin-enabled  true \
  --output none

ACR_SERVER=$(az acr show --name "$ACR_NAME" --query "loginServer" -o tsv)
ACR_USER=$(az acr credential show --name "$ACR_NAME" --query "username" -o tsv)
ACR_PASSWORD=$(az acr credential show --name "$ACR_NAME" --query "passwords[0].value" -o tsv)

echo "🐳 Build & Push de l'image..."
az acr login --name "$ACR_NAME"
docker build -t "$ACR_SERVER/blazormysqlapp:latest" .
docker push "$ACR_SERVER/blazormysqlapp:latest"

# ── 5. Azure Container Instances ─────────────────────────────────
echo "🚀 Déploiement ACI [$CONTAINER_NAME]..."

CONNECTION_STRING="Server=${MYSQL_HOST};Port=3306;Database=${MYSQL_DB};User Id=${MYSQL_ADMIN};Password=${MYSQL_PASSWORD};SslMode=Required;"

az container create \
  --resource-group        "$RESOURCE_GROUP" \
  --name                  "$CONTAINER_NAME" \
  --image                 "$ACR_SERVER/blazormysqlapp:latest" \
  --registry-login-server "$ACR_SERVER" \
  --registry-username     "$ACR_USER" \
  --registry-password     "$ACR_PASSWORD" \
  --cpu                   1 \
  --memory                1.5 \
  --ports                 8080 \
  --protocol              TCP \
  --os-type               Linux \
  --dns-name-label        "$DNS_LABEL" \
  --location              "$LOCATION" \
  --environment-variables \
      ASPNETCORE_ENVIRONMENT=Production \
      WEBSITES_PORT=8080 \
  --secure-environment-variables \
      "ConnectionStrings__DefaultConnection=$CONNECTION_STRING" \
  --restart-policy        Always \
  --output none

APP_URL=$(az container show \
  --resource-group "$RESOURCE_GROUP" \
  --name           "$CONTAINER_NAME" \
  --query          "ipAddress.fqdn" -o tsv)

echo ""
echo "══════════════════════════════════════════════"
echo "✅ Déploiement terminé !"
echo ""
echo "  🌐 Application : http://${APP_URL}:8080"
echo "  🗄️  MySQL       : $MYSQL_HOST"
echo "  📦 ACR         : $ACR_SERVER"
echo "  📁 Groupe      : $RESOURCE_GROUP"
echo "══════════════════════════════════════════════"
