# BlazorMySqlApp 🚀

Application **Blazor Server .NET 8** connectée à **Azure Database for MySQL Flexible Server**, déployée sur **Azure Container Instances (ACI)**.

---

## 📁 Structure du projet

```
BlazorMySqlApp/
├── App.razor                        ← Composant racine HTML
├── Routes.razor                     ← Router Blazor
├── _Imports.razor                   ← @using globaux
├── Program.cs                       ← AddRazorComponents + DI + migration auto
├── appsettings.json                 ← Config production
├── appsettings.Development.json     ← Config locale
│
├── Components/
│   ├── Layout/
│   │   ├── MainLayout.razor
│   │   └── NavMenu.razor
│   └── Pages/
│       ├── Home.razor               ← Dashboard avec stats
│       └── Products.razor           ← CRUD complet + recherche + modals
│
├── Data/
│   ├── AppDbContext.cs              ← DbContext EF Core
│   ├── ProductService.cs            ← Service CRUD
│   └── Migrations/                  ← Migrations EF Core
│
├── Models/Product.cs
├── Properties/launchSettings.json
├── wwwroot/css/app.css
├── Dockerfile                       ← Multi-stage build
├── docker-compose.yml               ← Dev local (MySQL + Blazor)
└── azure-deploy.sh                  ← Script de provisionnement Azure
```

---

## ⚡ Démarrage rapide (dev local)

### Prérequis
- [.NET 8 SDK](https://dotnet.microsoft.com/download)
- [Docker Desktop](https://www.docker.com/products/docker-desktop/)

```bash
# Démarre MySQL 8 + l'application Blazor
docker-compose up --build

# Accéder à l'application
open http://localhost:8080
```

---

## ☁️ Déploiement Azure — Azure Container Instances (ACI)

### Pourquoi ACI ?
- **Aucune infrastructure à gérer** — pas de plan, pas de cluster
- **Démarrage en ~30 secondes**
- **Facturation à la seconde** — idéal pour formation et démo
- **Simple** — une seule commande `az container create`

### Prérequis
```bash
az --version      # Azure CLI ≥ 2.50
docker --version
```

---

### Étape 1 — Connexion à Azure
```bash
az login

# Vérifier l'abonnement actif
az account show

# Changer d'abonnement si nécessaire
az account set --subscription "<ID_ABONNEMENT>"
```

---

### Étape 2 — Resource Group
```bash
az group create \
  --name     rg-blazormysql \
  --location francecentral
```

---

### Étape 3 — Azure Database for MySQL Flexible Server

```bash
# Créer le serveur (SSL activé par défaut)
az mysql flexible-server create \
  --resource-group   rg-blazormysql \
  --name             mysql-blazor-prod \
  --location         francecentral \
  --admin-user       blazoradmin \
  --admin-password   "VotreMotDePasse_Fort#2024!" \
  --sku-name         Standard_B1ms \
  --tier             Burstable \
  --version          8.0.21 \
  --storage-size     32 \
  --backup-retention 7 \
  --high-availability Disabled

# Créer la base de données
az mysql flexible-server db create \
  --resource-group rg-blazormysql \
  --server-name    mysql-blazor-prod \
  --database-name  blazordb

# ⚠️ ACI utilise une IP publique sortante — règle firewall obligatoire
az mysql flexible-server firewall-rule create \
  --resource-group   rg-blazormysql \
  --name             mysql-blazor-prod \
  --rule-name        "AllowAllAzureIPs" \
  --start-ip-address 0.0.0.0 \
  --end-ip-address   0.0.0.0

# Récupérer le hostname
az mysql flexible-server show \
  --resource-group rg-blazormysql \
  --name           mysql-blazor-prod \
  --query          "fullyQualifiedDomainName" \
  --output         tsv
# → mysql-blazor-prod.mysql.database.azure.com
```

> **SSL obligatoire** : la chaîne de connexion doit contenir `SslMode=Required`.

---

### Étape 4 — Vérifier la connexion SSL (optionnel)

```bash
# Télécharger le certificat CA Azure
curl -o DigiCertGlobalRootCA.crt.pem \
  https://dl.cacerts.digicert.com/DigiCertGlobalRootCA.crt.pem

# Tester la connexion sécurisée
mysql \
  --host=mysql-blazor-prod.mysql.database.azure.com \
  --user=blazoradmin \
  --password \
  --ssl-ca=DigiCertGlobalRootCA.crt.pem \
  --ssl-mode=VERIFY_CA \
  blazordb
```

---

### Étape 5 — Azure Container Registry (ACR)

```bash
# Créer le registre
az acr create \
  --resource-group rg-blazormysql \
  --name           acrblazormysql \
  --sku            Basic \
  --admin-enabled  true

# Récupérer le login server
ACR_SERVER=$(az acr show \
  --name  acrblazormysql \
  --query "loginServer" -o tsv)

# Build & push de l'image
az acr login --name acrblazormysql
docker build -t $ACR_SERVER/blazormysqlapp:latest .
docker push $ACR_SERVER/blazormysqlapp:latest
```

---

### Étape 6 — Déployer sur Azure Container Instances

```bash
# Récupérer les credentials ACR
ACR_USER=$(az acr credential show \
  --name acrblazormysql --query "username" -o tsv)
ACR_PASS=$(az acr credential show \
  --name acrblazormysql --query "passwords[0].value" -o tsv)

CONNECTION_STRING="Server=mysql-blazor-prod.mysql.database.azure.com;\
Port=3306;Database=blazordb;User Id=blazoradmin;\
Password=VotreMotDePasse_Fort#2024!;SslMode=Required;"

# Créer le container (CPU 1 core, RAM 1.5 Go)
az container create \
  --resource-group        rg-blazormysql \
  --name                  blazormysqlapp \
  --image                 $ACR_SERVER/blazormysqlapp:latest \
  --registry-login-server $ACR_SERVER \
  --registry-username     $ACR_USER \
  --registry-password     $ACR_PASS \
  --cpu                   1 \
  --memory                1.5 \
  --ports                 8080 \
  --protocol              TCP \
  --os-type               Linux \
  --dns-name-label        blazormysql-demo \
  --location              francecentral \
  --environment-variables \
      ASPNETCORE_ENVIRONMENT=Production \
  --secure-environment-variables \
      "ConnectionStrings__DefaultConnection=$CONNECTION_STRING" \
  --restart-policy        Always

# Récupérer l'URL publique
az container show \
  --resource-group rg-blazormysql \
  --name           blazormysqlapp \
  --query          "ipAddress.fqdn" \
  --output         tsv
# → blazormysql-demo.francecentral.azurecontainer.io
```

> **`--secure-environment-variables`** : les secrets (connection string, mots de passe)
> sont chiffrés au repos et masqués dans les logs et le portail Azure.
> Ne jamais utiliser `--environment-variables` pour des données sensibles.

---

### Étape 7 — Vérifier & gérer le conteneur

```bash
# Voir l'état du conteneur
az container show \
  --resource-group rg-blazormysql \
  --name           blazormysqlapp \
  --query          "{status:instanceView.state, fqdn:ipAddress.fqdn}" \
  --output         table

# Voir les logs en temps réel
az container logs \
  --resource-group rg-blazormysql \
  --name           blazormysqlapp \
  --follow

# Redémarrer le conteneur
az container restart \
  --resource-group rg-blazormysql \
  --name           blazormysqlapp

# Arrêter (stoppe la facturation)
az container stop \
  --resource-group rg-blazormysql \
  --name           blazormysqlapp

# Redémarrer
az container start \
  --resource-group rg-blazormysql \
  --name           blazormysqlapp
```

---

### Étape 8 — Mise à jour de l'image

```bash
# Rebuilder et pousser la nouvelle version
docker build -t $ACR_SERVER/blazormysqlapp:latest .
docker push $ACR_SERVER/blazormysqlapp:latest

# Recréer le conteneur ACI avec la nouvelle image
az container delete \
  --resource-group rg-blazormysql \
  --name           blazormysqlapp \
  --yes

# Relancer avec la même commande az container create (étape 6)
```

---

## 🔐 Chaîne de connexion — référence

| Paramètre   | Dev local (Docker Compose) | Azure Production (ACI) |
|-------------|---------------------------|------------------------|
| `Server`    | `mysql`                   | `<server>.mysql.database.azure.com` |
| `Port`      | `3306`                    | `3306` |
| `Database`  | `blazordb`                | `blazordb` |
| `User Id`   | `blazoruser`              | `blazoradmin` |
| `SslMode`   | `None`                    | `Required` ✅ |

---

## 🗑️ Nettoyer les ressources Azure

```bash
# Supprimer toutes les ressources en une commande
az group delete \
  --name  rg-blazormysql \
  --yes \
  --no-wait
```
