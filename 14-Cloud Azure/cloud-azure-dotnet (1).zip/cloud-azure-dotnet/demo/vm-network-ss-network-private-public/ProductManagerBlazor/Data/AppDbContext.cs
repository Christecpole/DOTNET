using Microsoft.EntityFrameworkCore;
using ProductManagerBlazor.Models;

namespace ProductManagerBlazor.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Product> Products => Set<Product>();
    public DbSet<Category> Categories => Set<Category>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>()
            .HasIndex(c => c.Name)
            .IsUnique();

        modelBuilder.Entity<Product>()
            .HasOne(p => p.Category)
            .WithMany(c => c.Products)
            .HasForeignKey(p => p.CategoryId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Category>().HasData(
            new Category { Id = 1, Name = "Électronique", Description = "Appareils et gadgets électroniques" },
            new Category { Id = 2, Name = "Livres", Description = "Livres papier et numériques" },
            new Category { Id = 3, Name = "Vêtements", Description = "Mode et accessoires" }
        );

        var now = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        modelBuilder.Entity<Product>().HasData(
            new Product { Id = 1, Name = "Laptop Pro 15", Description = "Ordinateur portable 15 pouces, 16Go RAM", Price = 1299.99m, Stock = 25, CategoryId = 1, CreatedAt = now },
            new Product { Id = 2, Name = "Clavier Mécanique RGB", Description = "Clavier gaming Cherry MX", Price = 89.99m, Stock = 150, CategoryId = 1, CreatedAt = now },
            new Product { Id = 3, Name = "Clean Code", Description = "Robert C. Martin", Price = 34.50m, Stock = 80, CategoryId = 2, CreatedAt = now },
            new Product { Id = 4, Name = "Design Patterns", Description = "Gang of Four", Price = 42.00m, Stock = 45, CategoryId = 2, CreatedAt = now },
            new Product { Id = 5, Name = "T-Shirt .NET", Description = "100% coton", Price = 24.99m, Stock = 200, CategoryId = 3, CreatedAt = now }
        );
    }
}
