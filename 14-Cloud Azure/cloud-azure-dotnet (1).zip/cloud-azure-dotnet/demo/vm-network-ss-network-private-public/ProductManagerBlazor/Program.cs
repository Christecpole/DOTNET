using Microsoft.EntityFrameworkCore;
using ProductManagerBlazor.Components;
using ProductManagerBlazor.Data;

var builder = WebApplication.CreateBuilder(args);

// === Blazor Server ===
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// === MySQL avec Pomelo ===
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? "Server=localhost;Port=3306;Database=productsdb;User=apiuser;Password=ApiPass2024!;";

var serverVersion = new MySqlServerVersion(new Version(8, 0, 36));

builder.Services.AddDbContextFactory<AppDbContext>(options =>
    options.UseMySql(connectionString, serverVersion, mysql =>
    {
        mysql.EnableRetryOnFailure(
            maxRetryCount: 10,
            maxRetryDelay: TimeSpan.FromSeconds(30),
            errorNumbersToAdd: null);
        mysql.CommandTimeout(60);
    }));

// === Antiforgery pour HTTP (Docker) ===
builder.Services.AddAntiforgery(options =>
{
    options.Cookie.SecurePolicy = CookieSecurePolicy.None;
    options.Cookie.SameSite = SameSiteMode.Lax;
});

var app = builder.Build();

// === Auto-création de la base ===
using (var scope = app.Services.CreateScope())
{
    var factory = scope.ServiceProvider.GetRequiredService<IDbContextFactory<AppDbContext>>();
    using var db = factory.CreateDbContext();
    var retries = 0;
    while (retries < 20)
    {
        try
        {
            app.Logger.LogInformation("Connexion MySQL ({attempt}/20)...", retries + 1);
            db.Database.EnsureCreated();
            app.Logger.LogInformation("✅ Base MySQL créée avec succès !");
            break;
        }
        catch (Exception ex)
        {
            retries++;
            app.Logger.LogWarning("⏳ MySQL pas prêt ({attempt}/20): {msg}", retries, ex.Message);
            if (retries >= 20) throw;
            Thread.Sleep(3000);
        }
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
