# 🚀 Déploiement API REST .NET 8 + MySQL sur Azure — Réseau Public/Privé

> **Projet** : ProductManager API REST (.NET 8 + EF Core + MySQL)  
> **Infra** : 2 VMs Azure (public + privé), 2 sous-réseaux, NSG isolés  
> **Source** : https://github.com/mohamedutopios/manager-produit-blazor-azure.git  
> **Persistance** : MySQL 8.0 conteneurisé sur VM privée

---

## 📋 Architecture cible

```
         Internet
            │
            ▼
    ┌───────────────┐
    │  IP Publique   │
    └──────┬────────┘
           │
    ═══════╪══════════════════════════════════════════
    │  VNet : 10.0.0.0/16                           │
    │                                                │
    │  ┌─────────────────────────────────┐           │
    │  │  snet-public (10.0.1.0/24)     │           │
    │  │  NSG: HTTP 80, SSH 22          │           │
    │  │                                 │           │
    │  │  ┌───────────────────────┐     │           │
    │  │  │  vm-app (Ubuntu)      │     │           │
    │  │  │  Docker               │     │           │
    │  │  │  ProductManager :8080 │     │           │
    │  │  │  IP publique ✅       │     │           │
    │  │  └──────────┬────────────┘     │           │
    │  └─────────────┼──────────────────┘           │
    │                │ port 3306                     │
    │  ┌─────────────┼──────────────────┐           │
    │  │  snet-private (10.0.2.0/24)    │           │
    │  │  NSG: MySQL 3306 depuis        │           │
    │  │       snet-public uniquement   │           │
    │  │  PAS d'IP publique ❌          │           │
    │  │                                 │           │
    │  │  ┌───────────────────────┐     │           │
    │  │  │  vm-db (Ubuntu)       │     │           │
    │  │  │  Docker               │     │           │
    │  │  │  MySQL 8.0 :3306      │     │           │
    │  │  │  Volume persistant    │     │           │
    │  │  └───────────────────────┘     │           │
    │  └─────────────────────────────────┘           │
    ═════════════════════════════════════════════════
```

**Principes de sécurité :**

- La VM MySQL n'a **aucune IP publique** → inaccessible depuis Internet
- Le NSG du subnet privé n'autorise que le trafic **depuis 10.0.1.0/24** sur le **port 3306**
- L'API se connecte à MySQL via l'**IP privée** de la VM DB (ex: 10.0.2.4)
- Seul le port 80 de la VM app est exposé sur Internet

---

## 📋 Prérequis

```bash
az login
az account set --subscription "NomDeLaSubscription"
az --version    # 2.x+
```

---

## Étape 1 — Variables

```bash
# === VARIABLES ===
RG="rg-product-api"
LOCATION="francecentral"
VNET_NAME="vnet-product"
SUBNET_PUBLIC="snet-public"
SUBNET_PRIVATE="snet-private"
NSG_PUBLIC="nsg-public"
NSG_PRIVATE="nsg-private"
VM_APP="vm-app"
VM_DB="vm-db"
IP_APP="pip-app"
ADMIN_USER="azureuser"
REPO_URL="https://github.com/mohamedutopios/manager-produit-blazor-azure.git"

# MySQL
MYSQL_ROOT_PASSWORD="Root@2024secure"
MYSQL_DATABASE="productsdb"
MYSQL_USER="apiuser"
MYSQL_PASSWORD="ApiPass@2024!"
```

---

## Étape 2 — Resource Group

```bash
az group create --name $RG --location $LOCATION
```

---

## Étape 3 — Réseau virtuel + 2 sous-réseaux

```bash
# 3.1 — Créer le VNet avec le subnet public
az network vnet create \
  --resource-group $RG \
  --name $VNET_NAME \
  --address-prefix 10.0.0.0/16 \
  --subnet-name $SUBNET_PUBLIC \
  --subnet-prefix 10.0.1.0/24

# 3.2 — Ajouter le subnet privé
az network vnet subnet create \
  --resource-group $RG \
  --vnet-name $VNET_NAME \
  --name $SUBNET_PRIVATE \
  --address-prefix 10.0.2.0/24
```

---

## Étape 4 — NSG (Network Security Groups)

### 4.1 — NSG pour le subnet PUBLIC (vm-app)

```bash
# Créer le NSG
az network nsg create \
  --resource-group $RG \
  --name $NSG_PUBLIC

# Autoriser HTTP (port 80) depuis Internet
az network nsg rule create \
  --resource-group $RG \
  --nsg-name $NSG_PUBLIC \
  --name AllowHTTP \
  --priority 100 \
  --access Allow \
  --direction Inbound \
  --protocol Tcp \
  --source-address-prefixes Internet \
  --destination-port-ranges 80

# Autoriser SSH (port 22) depuis Internet (pour administration)
az network nsg rule create \
  --resource-group $RG \
  --nsg-name $NSG_PUBLIC \
  --name AllowSSH \
  --priority 110 \
  --access Allow \
  --direction Inbound \
  --protocol Tcp \
  --source-address-prefixes Internet \
  --destination-port-ranges 22

# Associer au subnet public
az network vnet subnet update \
  --resource-group $RG \
  --vnet-name $VNET_NAME \
  --name $SUBNET_PUBLIC \
  --network-security-group $NSG_PUBLIC
```

### 4.2 — NSG pour le subnet PRIVÉ (vm-db)

```bash
# Créer le NSG
az network nsg create \
  --resource-group $RG \
  --name $NSG_PRIVATE

# Autoriser MySQL (3306) UNIQUEMENT depuis le subnet public
az network nsg rule create \
  --resource-group $RG \
  --nsg-name $NSG_PRIVATE \
  --name AllowMySQLFromApp \
  --priority 100 \
  --access Allow \
  --direction Inbound \
  --protocol Tcp \
  --source-address-prefixes 10.0.1.0/24 \
  --destination-port-ranges 3306

# Autoriser SSH UNIQUEMENT depuis le subnet public (pour admin via jump)
az network nsg rule create \
  --resource-group $RG \
  --nsg-name $NSG_PRIVATE \
  --name AllowSSHFromApp \
  --priority 110 \
  --access Allow \
  --direction Inbound \
  --protocol Tcp \
  --source-address-prefixes 10.0.1.0/24 \
  --destination-port-ranges 22

# BLOQUER tout le reste depuis Internet (règle par défaut NSG)
# Pas besoin de règle explicite : le NSG bloque par défaut tout Inbound non autorisé

# Associer au subnet privé
az network vnet subnet update \
  --resource-group $RG \
  --vnet-name $VNET_NAME \
  --name $SUBNET_PRIVATE \
  --network-security-group $NSG_PRIVATE
```

**Résumé des règles :**

| NSG | Règle | Source | Port | Action |
|-----|-------|--------|------|--------|
| nsg-public | AllowHTTP | Internet | 80 | ✅ Allow |
| nsg-public | AllowSSH | Internet | 22 | ✅ Allow |
| nsg-private | AllowMySQLFromApp | 10.0.1.0/24 | 3306 | ✅ Allow |
| nsg-private | AllowSSHFromApp | 10.0.1.0/24 | 22 | ✅ Allow |
| nsg-private | (default) | Internet | * | ❌ Deny |

---

## Étape 5 — Cloud-init pour la VM Base de Données (MySQL)

```bash
cat > cloud-init-db.yaml << 'EOF'
#cloud-config
package_update: true
package_upgrade: true

packages:
  - ca-certificates
  - curl

runcmd:
  # --- Installer Docker ---
  - curl -fsSL https://get.docker.com | sh
  - systemctl enable docker
  - systemctl start docker
  - usermod -aG docker azureuser

  # --- Créer le volume pour la persistance ---
  - docker volume create mysql_data

  # --- Lancer MySQL ---
  - >
    docker run -d
    --name mysql
    --restart always
    -p 3306:3306
    -v mysql_data:/var/lib/mysql
    -e MYSQL_ROOT_PASSWORD=Root@2024secure
    -e MYSQL_DATABASE=productsdb
    -e MYSQL_USER=apiuser
    -e MYSQL_PASSWORD=ApiPass@2024!
    mysql:8.0
    --default-authentication-plugin=mysql_native_password
    --bind-address=0.0.0.0

  # --- Log ---
  - echo "=== MySQL déployé ===" >> /var/log/cloud-init-app.log
  - sleep 10
  - docker ps >> /var/log/cloud-init-app.log
EOF
```

**Points importants :**

- `--bind-address=0.0.0.0` : MySQL écoute sur toutes les interfaces (nécessaire pour que vm-app puisse s'y connecter)
- `mysql_native_password` : compatibilité avec le driver Pomelo EF Core
- `docker volume create mysql_data` : les données persistent même si le conteneur est recréé
- Le NSG empêche tout accès depuis Internet — seul le subnet 10.0.1.0/24 peut atteindre le port 3306

---

## Étape 6 — Cloud-init pour la VM Application (API .NET)

```bash
cat > cloud-init-app.yaml << 'EOF'
#cloud-config
package_update: true
package_upgrade: true

packages:
  - ca-certificates
  - curl
  - git

runcmd:
  # --- Installer Docker ---
  - curl -fsSL https://get.docker.com | sh
  - systemctl enable docker
  - systemctl start docker
  - usermod -aG docker azureuser

  # --- Cloner le projet ---
  - git clone https://github.com/mohamedutopios/manager-produit-blazor-azure.git /opt/app

  # --- Builder l'image ---
  - cd /opt/app && docker build -t productmanager:1.0 .

  # --- Lancer le conteneur ---
  # La connection string pointe vers l'IP privée de vm-db (10.0.2.4)
  # Elle sera mise à jour après la création de la VM DB
  - >
    docker run -d
    --name productmanager
    --restart always
    -p 80:8080
    -e "ConnectionStrings__DefaultConnection=Server=DB_PRIVATE_IP;Port=3306;Database=productsdb;User=apiuser;Password=ApiPass@2024!;"
    -e ASPNETCORE_ENVIRONMENT=Development
    productmanager:1.0

  # --- Log ---
  - echo "=== ProductManager déployé ===" >> /var/log/cloud-init-app.log
  - docker ps >> /var/log/cloud-init-app.log
EOF
```

> ⚠️ **Note** : `DB_PRIVATE_IP` sera remplacé par la vraie IP privée de la VM DB à l'étape 8.

---

## Étape 7 — Créer la VM Base de Données (subnet privé, SANS IP publique)

```bash
# Créer la VM DB sans IP publique
az vm create \
  --resource-group $RG \
  --name $VM_DB \
  --image "Ubuntu2204" \
  --size "Standard_B2s" \
  --admin-username $ADMIN_USER \
  --generate-ssh-keys \
  --vnet-name $VNET_NAME \
  --subnet $SUBNET_PRIVATE \
  --public-ip-address "" \
  --nsg "" \
  --custom-data cloud-init-db.yaml

# Récupérer l'IP privée de la VM DB
DB_PRIVATE_IP=$(az vm show \
  --resource-group $RG \
  --name $VM_DB \
  --show-details \
  --query privateIps -o tsv)

echo "IP privée de la VM DB : $DB_PRIVATE_IP"
# Typiquement : 10.0.2.4
```

**Points importants :**

- `--public-ip-address ""` : **aucune IP publique** → impossible d'accéder depuis Internet
- `--nsg ""` : pas de NSG au niveau NIC (le NSG est sur le subnet)
- La VM est accessible **uniquement depuis le VNet** (10.0.0.0/16)

---

## Étape 8 — Créer la VM Application (subnet public, AVEC IP publique)

```bash
# Mettre à jour le cloud-init avec la vraie IP privée de la VM DB
sed -i "s/DB_PRIVATE_IP/$DB_PRIVATE_IP/g" cloud-init-app.yaml

# Vérifier que le remplacement est correct
grep "Server=" cloud-init-app.yaml
# Doit afficher : Server=10.0.2.4;Port=3306;...

# Créer l'IP publique
az network public-ip create \
  --resource-group $RG \
  --name $IP_APP \
  --sku Standard \
  --allocation-method Static

# Créer la VM App
az vm create \
  --resource-group $RG \
  --name $VM_APP \
  --image "Ubuntu2204" \
  --size "Standard_B2s" \
  --admin-username $ADMIN_USER \
  --generate-ssh-keys \
  --vnet-name $VNET_NAME \
  --subnet $SUBNET_PUBLIC \
  --public-ip-address $IP_APP \
  --nsg "" \
  --custom-data cloud-init-app.yaml

# Récupérer l'IP publique
APP_PUBLIC_IP=$(az network public-ip show \
  --resource-group $RG \
  --name $IP_APP \
  --query ipAddress -o tsv)

echo "IP publique de l'app : $APP_PUBLIC_IP"
echo "URL : http://$APP_PUBLIC_IP"
```

---

## Étape 9 — Vérifier le déploiement (attendre 3-5 min)

### 9.1 — Vérifier la VM App

```bash
# SSH sur la VM App
ssh azureuser@$APP_PUBLIC_IP

# Vérifier le cloud-init
cloud-init status          # Attendre "done"
cat /var/log/cloud-init-app.log

# Vérifier Docker
docker ps
# CONTAINER ID   IMAGE                  STATUS    PORTS
# abc123         productmanager:1.0     Up        0.0.0.0:80->8080/tcp

# Vérifier les logs de l'API
docker logs productmanager
# Attendre : ✅ Base MySQL créée avec succès !

# Tester localement
curl http://localhost/swagger
curl http://localhost/api/products
curl http://localhost/healthz
```

### 9.2 — Vérifier la VM DB (via jump depuis vm-app)

```bash
# Depuis vm-app (déjà connecté en SSH)
ssh azureuser@$DB_PRIVATE_IP      # ex: ssh azureuser@10.0.2.4

# Sur vm-db :
cloud-init status
docker ps
# CONTAINER ID   IMAGE      STATUS    PORTS
# def456         mysql:8.0  Up        0.0.0.0:3306->3306/tcp

# Tester MySQL
docker exec -it mysql mysql -u apiuser -p'ApiPass@2024!' productsdb -e "SHOW TABLES;"
# Doit afficher : Categories, Products, __EFMigrationsHistory

# Vérifier les données seed
docker exec -it mysql mysql -u apiuser -p'ApiPass@2024!' productsdb -e "SELECT * FROM Products;"

# Quitter vm-db
exit
```

### 9.3 — Tester depuis Internet

```bash
# Depuis votre poste local
curl http://$APP_PUBLIC_IP/healthz
# Healthy

curl http://$APP_PUBLIC_IP/api/categories | jq
# 3 catégories (seed data)

curl http://$APP_PUBLIC_IP/api/products | jq
# 5 produits (seed data)

# Créer un produit
curl -X POST http://$APP_PUBLIC_IP/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Clavier Azure",
    "description": "Clavier pour le cloud",
    "price": 79.99,
    "stock": 50,
    "categoryId": 1
  }' | jq

# Swagger UI dans le navigateur :
echo "http://$APP_PUBLIC_IP/swagger"
```

### 9.4 — Vérifier l'isolation réseau

```bash
# Depuis votre poste local, essayer d'accéder à MySQL directement :
mysql -h $APP_PUBLIC_IP -u apiuser -p productsdb
# ❌ Connection refused (port 3306 pas ouvert sur vm-app)

# La VM DB n'a pas d'IP publique, donc :
# ping 10.0.2.4   → impossible depuis Internet
# ssh 10.0.2.4    → impossible depuis Internet
# mysql 10.0.2.4  → impossible depuis Internet
# ✅ Seule vm-app (10.0.1.x) peut joindre vm-db sur le port 3306
```

---

## Étape 10 — Vérifier la persistance

```bash
# Créer un produit
curl -X POST http://$APP_PUBLIC_IP/api/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Persistance","price":9.99,"stock":1,"categoryId":1}' | jq

# Redémarrer le conteneur API
ssh azureuser@$APP_PUBLIC_IP "docker restart productmanager"

# Vérifier que le produit existe toujours
curl "http://$APP_PUBLIC_IP/api/products?search=persistance" | jq
# ✅ Le produit est toujours là (stocké dans MySQL)

# Redémarrer le conteneur MySQL
ssh azureuser@$APP_PUBLIC_IP "ssh azureuser@$DB_PRIVATE_IP 'docker restart mysql'"

# Attendre 10 secondes puis re-vérifier
sleep 10
curl "http://$APP_PUBLIC_IP/api/products?search=persistance" | jq
# ✅ Toujours là (volume Docker persistant)
```

---

## Étape 11 — Commandes de gestion

### Gestion de l'API (vm-app)

| Commande | Description |
|----------|-------------|
| `ssh azureuser@$APP_PUBLIC_IP` | Connexion SSH |
| `docker ps` | État du conteneur |
| `docker logs -f productmanager` | Logs temps réel |
| `docker restart productmanager` | Redémarrer l'API |
| `curl http://localhost/healthz` | Health check local |

### Gestion de MySQL (vm-db, via jump)

| Commande | Description |
|----------|-------------|
| `ssh azureuser@$DB_PRIVATE_IP` | SSH depuis vm-app |
| `docker ps` | État MySQL |
| `docker logs -f mysql` | Logs MySQL |
| `docker exec -it mysql mysql -u apiuser -p productsdb` | Shell MySQL |
| `docker exec mysql mysqldump -u root -p productsdb > backup.sql` | Backup |

### Mise à jour de l'application

```bash
# Sur vm-app
ssh azureuser@$APP_PUBLIC_IP

cd /opt/app
git pull origin main
docker build -t productmanager:2.0 .
docker stop productmanager && docker rm productmanager
docker run -d --name productmanager --restart always \
  -p 80:8080 \
  -e "ConnectionStrings__DefaultConnection=Server=10.0.2.4;Port=3306;Database=productsdb;User=apiuser;Password=ApiPass@2024!;" \
  -e ASPNETCORE_ENVIRONMENT=Development \
  productmanager:2.0
```

### Backup MySQL

```bash
# Depuis vm-app, jump vers vm-db
ssh azureuser@$DB_PRIVATE_IP

# Dump de la base
docker exec mysql mysqldump \
  -u root -p'Root@2024secure' productsdb > /home/azureuser/backup_$(date +%Y%m%d).sql

# Copier le backup vers vm-app
exit  # retour sur vm-app
scp azureuser@10.0.2.4:/home/azureuser/backup_*.sql ~/

# Puis rapatrier sur votre poste local
exit  # retour sur votre poste
scp azureuser@$APP_PUBLIC_IP:~/backup_*.sql ./
```

---

## Étape 12 — Nettoyage

```bash
# ⚠️ Supprime TOUT
az group delete --name $RG --yes --no-wait

# Vérifier
az group list --query "[?name=='rg-product-api']" -o table
```

> 💰 **Coût** : 2x Standard_B2s ≈ 60€/mois. Supprimer après le lab.

---

## Récapitulatif — Script complet

```bash
#!/bin/bash
# === Déploiement API REST + MySQL sur Azure (Public/Privé) ===
set -e

# --- Variables ---
RG="rg-product-api"
LOCATION="francecentral"
VNET_NAME="vnet-product"
SUBNET_PUBLIC="snet-public"
SUBNET_PRIVATE="snet-private"
NSG_PUBLIC="nsg-public"
NSG_PRIVATE="nsg-private"
VM_APP="vm-app"
VM_DB="vm-db"
IP_APP="pip-app"
ADMIN_USER="azureuser"

echo "=== 1. Resource Group ==="
az group create --name $RG --location $LOCATION

echo "=== 2. VNet + Subnets ==="
az network vnet create \
  -g $RG --name $VNET_NAME \
  --address-prefix 10.0.0.0/16 \
  --subnet-name $SUBNET_PUBLIC --subnet-prefix 10.0.1.0/24

az network vnet subnet create \
  -g $RG --vnet-name $VNET_NAME \
  --name $SUBNET_PRIVATE --address-prefix 10.0.2.0/24

echo "=== 3. NSG Public ==="
az network nsg create -g $RG --name $NSG_PUBLIC

az network nsg rule create -g $RG --nsg-name $NSG_PUBLIC \
  --name AllowHTTP --priority 100 --access Allow --direction Inbound \
  --protocol Tcp --source-address-prefixes Internet --destination-port-ranges 80

az network nsg rule create -g $RG --nsg-name $NSG_PUBLIC \
  --name AllowSSH --priority 110 --access Allow --direction Inbound \
  --protocol Tcp --source-address-prefixes Internet --destination-port-ranges 22

az network vnet subnet update -g $RG --vnet-name $VNET_NAME \
  --name $SUBNET_PUBLIC --network-security-group $NSG_PUBLIC

echo "=== 4. NSG Private ==="
az network nsg create -g $RG --name $NSG_PRIVATE

az network nsg rule create -g $RG --nsg-name $NSG_PRIVATE \
  --name AllowMySQLFromApp --priority 100 --access Allow --direction Inbound \
  --protocol Tcp --source-address-prefixes 10.0.1.0/24 --destination-port-ranges 3306

az network nsg rule create -g $RG --nsg-name $NSG_PRIVATE \
  --name AllowSSHFromApp --priority 110 --access Allow --direction Inbound \
  --protocol Tcp --source-address-prefixes 10.0.1.0/24 --destination-port-ranges 22

az network vnet subnet update -g $RG --vnet-name $VNET_NAME \
  --name $SUBNET_PRIVATE --network-security-group $NSG_PRIVATE

echo "=== 5. Cloud-init DB ==="
cat > /tmp/cloud-init-db.yaml << 'DBEOF'
#cloud-config
package_update: true
package_upgrade: true
packages:
  - ca-certificates
  - curl
runcmd:
  - curl -fsSL https://get.docker.com | sh
  - systemctl enable docker
  - systemctl start docker
  - usermod -aG docker azureuser
  - docker volume create mysql_data
  - >
    docker run -d
    --name mysql
    --restart always
    -p 3306:3306
    -v mysql_data:/var/lib/mysql
    -e MYSQL_ROOT_PASSWORD=Root@2024secure
    -e MYSQL_DATABASE=productsdb
    -e MYSQL_USER=apiuser
    -e MYSQL_PASSWORD=ApiPass@2024!
    mysql:8.0
    --default-authentication-plugin=mysql_native_password
    --bind-address=0.0.0.0
  - echo "=== MySQL OK ===" >> /var/log/cloud-init-app.log
DBEOF

echo "=== 6. VM DB (privée, sans IP publique) ==="
az vm create \
  -g $RG --name $VM_DB \
  --image Ubuntu2204 --size Standard_B2s \
  --admin-username $ADMIN_USER --generate-ssh-keys \
  --vnet-name $VNET_NAME --subnet $SUBNET_PRIVATE \
  --public-ip-address "" --nsg "" \
  --custom-data /tmp/cloud-init-db.yaml

DB_PRIVATE_IP=$(az vm show -g $RG -n $VM_DB -d --query privateIps -o tsv)
echo "DB IP privée: $DB_PRIVATE_IP"

echo "=== 7. Cloud-init App ==="
cat > /tmp/cloud-init-app.yaml << APPEOF
#cloud-config
package_update: true
package_upgrade: true
packages:
  - ca-certificates
  - curl
  - git
runcmd:
  - curl -fsSL https://get.docker.com | sh
  - systemctl enable docker
  - systemctl start docker
  - usermod -aG docker azureuser
  - git clone https://github.com/mohamedutopios/manager-produit-blazor-azure.git /opt/app
  - cd /opt/app && docker build -t productmanager:1.0 .
  - >
    docker run -d
    --name productmanager
    --restart always
    -p 80:8080
    -e "ConnectionStrings__DefaultConnection=Server=${DB_PRIVATE_IP};Port=3306;Database=productsdb;User=apiuser;Password=ApiPass@2024!;"
    -e ASPNETCORE_ENVIRONMENT=Development
    productmanager:1.0
  - echo "=== App OK ===" >> /var/log/cloud-init-app.log
APPEOF

echo "=== 8. IP publique ==="
az network public-ip create \
  -g $RG --name $IP_APP --sku Standard --allocation-method Static

echo "=== 9. VM App (publique) ==="
az vm create \
  -g $RG --name $VM_APP \
  --image Ubuntu2204 --size Standard_B2s \
  --admin-username $ADMIN_USER --generate-ssh-keys \
  --vnet-name $VNET_NAME --subnet $SUBNET_PUBLIC \
  --public-ip-address $IP_APP --nsg "" \
  --custom-data /tmp/cloud-init-app.yaml

APP_PUBLIC_IP=$(az network public-ip show -g $RG -n $IP_APP --query ipAddress -o tsv)

echo ""
echo "============================================"
echo "✅ Déploiement terminé !"
echo "============================================"
echo ""
echo "API publique  : http://$APP_PUBLIC_IP"
echo "Swagger       : http://$APP_PUBLIC_IP/swagger"
echo "Health check  : http://$APP_PUBLIC_IP/healthz"
echo ""
echo "DB IP privée  : $DB_PRIVATE_IP (non accessible depuis Internet)"
echo ""
echo "⏳ Attendre 3-5 min pour que le cloud-init termine."
echo ""
echo "SSH vm-app    : ssh azureuser@$APP_PUBLIC_IP"
echo "SSH vm-db     : ssh azureuser@$APP_PUBLIC_IP puis ssh azureuser@$DB_PRIVATE_IP"
echo ""
echo "Nettoyage     : az group delete --name $RG --yes --no-wait"
```
