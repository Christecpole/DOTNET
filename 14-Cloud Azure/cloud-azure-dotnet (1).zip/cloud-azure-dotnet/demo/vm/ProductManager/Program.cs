using ProductManager.Components;
using ProductManager.Services;


var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddSingleton<ProductService>();

// FIX 1: SignalR détaillé pour debug
builder.Services.AddSignalR(options =>
{
    options.EnableDetailedErrors = true;
    options.HandshakeTimeout = TimeSpan.FromSeconds(30);
    options.KeepAliveInterval = TimeSpan.FromSeconds(15);
});

// FIX 2: Antiforgery compatible HTTP (pas HTTPS) dans Docker
builder.Services.AddAntiforgery(options =>
{
    options.Cookie.SecurePolicy = CookieSecurePolicy.None;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.HttpOnly = true;
});

// FIX 3: Data Protection en mémoire (pas de fichier persistent dans Docker)
builder.Services.AddDataProtection();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}

// FIX: Middleware qui supprime la compression WebSocket ajoutée par Docker Desktop Mac
app.Use(async (context, next) =>
{
    context.Request.Headers.Remove("Sec-WebSocket-Extensions");
    await next();
});

app.UseWebSockets(new Microsoft.AspNetCore.Builder.WebSocketOptions
{
    AllowedOrigins = { "*" },
    KeepAliveInterval = TimeSpan.FromSeconds(30)
});
app.UseStaticFiles();
app.UseRouting();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
