using ProductManager.Models;

namespace ProductManager.Services;

public class ProductService
{
    private readonly List<Product> _products = new()
    {
        new() { Id = 1, Name = "MacBook Pro 16", Category = "Informatique", Price = 2799.99m, Stock = 15 },
        new() { Id = 2, Name = "iPhone 15 Pro", Category = "Téléphonie", Price = 1199.00m, Stock = 42 },
        new() { Id = 3, Name = "AirPods Pro 2", Category = "Audio", Price = 279.00m, Stock = 120 },
        new() { Id = 4, Name = "iPad Air M2", Category = "Informatique", Price = 799.00m, Stock = 30 },
        new() { Id = 5, Name = "Samsung Galaxy S24", Category = "Téléphonie", Price = 899.00m, Stock = 55 },
        new() { Id = 6, Name = "Sony WH-1000XM5", Category = "Audio", Price = 349.99m, Stock = 25 },
        new() { Id = 7, Name = "Dell XPS 15", Category = "Informatique", Price = 1899.00m, Stock = 18 },
        new() { Id = 8, Name = "Logitech MX Master 3S", Category = "Accessoires", Price = 99.99m, Stock = 200 },
    };

    private int _nextId = 9;

    public List<Product> GetAll() => _products.OrderByDescending(p => p.CreatedAt).ToList();

    public Product? GetById(int id) => _products.FirstOrDefault(p => p.Id == id);

    public List<string> GetCategories() => _products.Select(p => p.Category).Distinct().OrderBy(c => c).ToList();

    public List<Product> Search(string? query, string? category)
    {
        var result = _products.AsEnumerable();

        if (!string.IsNullOrWhiteSpace(query))
            result = result.Where(p => p.Name.Contains(query, StringComparison.OrdinalIgnoreCase));

        if (!string.IsNullOrWhiteSpace(category) && category != "Toutes")
            result = result.Where(p => p.Category == category);

        return result.OrderByDescending(p => p.CreatedAt).ToList();
    }

    public void Add(Product product)
    {
        product.Id = _nextId++;
        product.CreatedAt = DateTime.Now;
        _products.Add(product);
    }

    public void Update(Product product)
    {
        var existing = _products.FirstOrDefault(p => p.Id == product.Id);
        if (existing is not null)
        {
            existing.Name = product.Name;
            existing.Category = product.Category;
            existing.Price = product.Price;
            existing.Stock = product.Stock;
            existing.IsActive = product.IsActive;
        }
    }

    public void Delete(int id) => _products.RemoveAll(p => p.Id == id);

    public int TotalCount => _products.Count;
    public int ActiveCount => _products.Count(p => p.IsActive);
    public decimal TotalValue => _products.Sum(p => p.Price * p.Stock);
}
