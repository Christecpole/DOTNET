# 🚀 Déploiement de ProductManager sur Azure VM

## Table of Contents

<details>
<summary>Contents</summary>

1. [📋 Prérequis](#-prérequis)
1. [☁️ Étape 1 — Créer la VM Azure (Interface Graphique)](#-étape-1--créer-la-vm-azure-interface-graphique)
   1. [1.1 Créer un Resource Group](#11-créer-un-resource-group)
   1. [1.2 Créer la VM](#12-créer-la-vm)
   1. [1.3 Configurer le NSG — Ouvrir les ports](#13-configurer-le-nsg--ouvrir-les-ports)
   1. [1.4 Récupérer l'IP publique](#14-récupérer-lip-publique)
1. [🐳 Option A — Déployer via Docker (conteneur)](#-option-a--déployer-via-docker-conteneur)
   1. [A.1 Se connecter à la VM](#a1-se-connecter-à-la-vm)
   1. [A.2 Transférer le projet](#a2-transférer-le-projet)
   1. [A.3 Builder et lancer le conteneur](#a3-builder-et-lancer-le-conteneur)
   1. [A.4 Vérifier le déploiement](#a4-vérifier-le-déploiement)
1. [⚙️ Option B — Déployer directement (sans Docker)](#-option-b--déployer-directement-sans-docker)
1. [🔁 Redémarrage automatique au reboot](#-redémarrage-automatique-au-reboot)
1. [🧪 Tester l'API](#-tester-lapi)
1. [🧹 Supprimer les ressources Azure](#-supprimer-les-ressources-azure)

</details>

---

## 📋 Prérequis

| Outil | Usage |
|---|---|
| Compte Azure actif | https://portal.azure.com |
| Projet `ProductManager` avec `Dockerfile` | Prêt à builder |
| Client SSH | Terminal Linux/Mac ou PuTTY sur Windows |

---

## ☁️ Étape 1 — Créer la VM Azure (Interface Graphique)

### 1.1 Créer un Resource Group

1. Dans la barre de recherche, tape **"Resource groups"** → **+ Create**
2. Remplis les champs :
   - **Subscription** : ta souscription
   - **Resource group** : `rg-productmanager-demo`
   - **Region** : `France Central`
3. Clique sur **Review + create** → **Create**

---

### 1.2 Créer la VM

1. Dans la barre de recherche, tape **"Virtual machines"** → **+ Create** → **Azure virtual machine**

**Onglet Basics**

- **Subscription** : ta souscription
- **Resource group** : `rg-productmanager-demo`
- **Virtual machine name** : `vm-productmanager`
- **Region** : `France Central`
- **Availability options** : `No infrastructure redundancy required` *(démo)*
- **Image** : `Ubuntu Server 24.04 LTS`
- **Size** : `Standard_B1s` *(1 vCPU, 1 Go RAM — suffisant pour la démo)*
- **Authentication type** : `SSH public key`
- **Username** : `azureuser`
- **SSH public key source** : `Generate new key pair`
- **Key pair name** : `vm-productmanager-key`

> 📥 Lors du clic sur **Create**, Azure proposera de télécharger la clé `.pem` — **ne pas manquer cette étape**.

**Onglet Disks**

- **OS disk type** : `Standard SSD` *(économique pour la démo)*
- Laisser le reste par défaut

**Onglet Networking**

- **Virtual network** : laisser la valeur générée automatiquement
- **Subnet** : laisser par défaut
- **Public IP** : laisser la valeur générée automatiquement *(une IP publique sera créée)*
- **NIC network security group** : `Basic`
- **Public inbound ports** : `Allow selected ports`
- **Select inbound ports** : `SSH (22)`

> ⚠️ On n'ouvre que le port SSH ici. Le port applicatif sera ouvert manuellement via le NSG à l'étape suivante.

**Onglet Management**

- Laisser tout par défaut

**Onglet Advanced — custom-data**

Le champ **custom-data** permet d'exécuter automatiquement un script au **premier démarrage** de la VM. Cela installe Docker sans avoir à se connecter manuellement.

Dans le champ **Custom data** (section *cloud-init*), colle le script suivant :

```bash
#!/bin/bash
# Mise à jour du système
apt-get update -y
apt-get upgrade -y

# Installation de Docker
curl -fsSL https://get.docker.com | sh

# Ajout de l'utilisateur azureuser au groupe docker
usermod -aG docker azureuser

# Activation et démarrage de Docker
systemctl enable docker
systemctl start docker

echo "✅ Docker installé avec succès" >> /var/log/custom-data.log
```

**Onglet Tags**

- Laisser par défaut

2. Clique sur **Review + create**
3. Vérifie le résumé puis clique sur **Create**
4. Lorsque la fenêtre **"Generate new key pair"** apparaît, clique sur **Download private key and create resource**
5. Attends le message **"Your deployment is complete"** puis clique sur **Go to resource**

---

### 1.3 Configurer le NSG — Ouvrir les ports

Le NSG (Network Security Group) est le pare-feu Azure qui contrôle le trafic entrant et sortant de la VM. Il faut ouvrir le port **8080** pour accéder à l'API.

1. Dans ta VM → menu gauche → **Networking** (section *Settings*)
2. Clique sur l'onglet **Inbound port rules**
3. Clique sur **+ Add inbound port rule**
4. Remplis les champs :
   - **Source** : `Any`
   - **Source port ranges** : `*`
   - **Destination** : `Any`
   - **Service** : `Custom`
   - **Destination port ranges** : `8080`
   - **Protocol** : `TCP`
   - **Action** : `Allow`
   - **Priority** : `1010`
   - **Name** : `Allow-HTTP-8080`
5. Clique sur **Add**

> ℹ️ Le port 22 (SSH) a été ouvert automatiquement lors de la création de la VM.

---

### 1.4 Récupérer l'IP publique

1. Dans ta VM → menu gauche → **Overview**
2. Note la valeur du champ **Public IP address**

```
Ex : 20.216.180.45
```

Cette IP sera utilisée pour se connecter en SSH et pour accéder à l'API.

---

## 🐳 Option A — Déployer via Docker (conteneur)

### A.1 Se connecter à la VM

Sur **Linux / Mac** :

```bash
# Donner les bonnes permissions à la clé
chmod 400 ~/Downloads/vm-productmanager-key.pem

# Se connecter en SSH
ssh -i ~/Downloads/vm-productmanager-key.pem azureuser@<IP_PUBLIQUE>
```

Sur **Windows** (PowerShell) :

```powershell
ssh -i C:\Users\<ton-user>\Downloads\vm-productmanager-key.pem azureuser@<IP_PUBLIQUE>
```

> ⏳ Si tu viens de créer la VM, attends 2-3 minutes que le script custom-data finisse de s'exécuter.

Pour vérifier que Docker est bien installé :

```bash
docker --version
# Docker version 27.x.x, build ...
```

---

### A.2 Transférer le projet

Depuis ta **machine locale**, copie le projet vers la VM :

```bash
scp -i ~/Downloads/vm-productmanager-key.pem -r ./ProductManager azureuser@<IP_PUBLIQUE>:~/
```

Sur **Windows** (PowerShell) :

```powershell
scp -i C:\Users\<ton-user>\Downloads\vm-productmanager-key.pem -r .\ProductManager azureuser@<IP_PUBLIQUE>:~/
```

---

### A.3 Builder et lancer le conteneur

**Reconnecte-toi à la VM**, puis :

```bash
# Aller dans le dossier du projet
cd ~/ProductManager

# Builder l'image Docker
docker build -t productmanager:latest .

# Lancer le conteneur
docker run -d \
  --name productmanager \
  --restart unless-stopped \
  -p 8080:8080 \
  productmanager:latest
```

Explication des options :
- `-d` : mode détaché (tourne en arrière-plan)
- `--name` : nom du conteneur
- `--restart unless-stopped` : redémarre automatiquement en cas de crash ou reboot
- `-p 8080:8080` : mappe le port 8080 de la VM vers le port 8080 du conteneur

---

### A.4 Vérifier le déploiement

```bash
# Vérifier que le conteneur tourne
docker ps

# Consulter les logs
docker logs productmanager

# Tester localement depuis la VM
curl http://localhost:8080
```

---

## ⚙️ Option B — Déployer directement (sans Docker)

Si tu veux déployer sans Docker, le custom-data doit installer le runtime .NET au lieu de Docker.

**Script custom-data alternatif** (à coller lors de la création de la VM) :

```bash
#!/bin/bash
apt-get update -y

# Installation du runtime .NET 8
wget https://packages.microsoft.com/config/ubuntu/24.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
dpkg -i packages-microsoft-prod.deb
apt-get update -y
apt-get install -y aspnetcore-runtime-8.0

echo "✅ .NET 8 Runtime installé" >> /var/log/custom-data.log
```

Ensuite, depuis ta machine locale, **publie et transfère** le binaire :

```bash
# Sur ta machine locale — publier l'application
dotnet publish -c Release -o ./publish

# Transférer les fichiers publiés vers la VM
scp -i ~/Downloads/vm-productmanager-key.pem -r ./publish azureuser@<IP_PUBLIQUE>:~/productmanager
```

Sur la VM, **lancer l'application** :

```bash
cd ~/productmanager
ASPNETCORE_URLS=http://+:8080 dotnet ProductManager.dll
```

---

## 🔁 Redémarrage automatique au reboot (Option B uniquement)

Pour que l'application redémarre automatiquement avec la VM, crée un service **systemd** :

```bash
sudo nano /etc/systemd/system/productmanager.service
```

Colle le contenu suivant :

```ini
[Unit]
Description=ProductManager API
After=network.target

[Service]
WorkingDirectory=/home/azureuser/productmanager
ExecStart=/usr/bin/dotnet /home/azureuser/productmanager/ProductManager.dll
Restart=always
RestartSec=5
User=azureuser
Environment=ASPNETCORE_URLS=http://+:8080
Environment=ASPNETCORE_ENVIRONMENT=Development

[Install]
WantedBy=multi-user.target
```

Active et démarre le service :

```bash
sudo systemctl daemon-reload
sudo systemctl enable productmanager
sudo systemctl start productmanager

# Vérifier le statut
sudo systemctl status productmanager
```

> ℹ️ Avec Docker (Option A), le flag `--restart unless-stopped` remplace déjà ce mécanisme.

---

## 🧪 Tester l'API

Depuis ton **navigateur** ou **curl** sur ta machine locale :

```bash
# Tester la racine
curl http://<IP_PUBLIQUE>:8080

# Tester un endpoint (exemple)
curl http://<IP_PUBLIQUE>:8080/api/products
```

Swagger UI (si activé) :

```
http://<IP_PUBLIQUE>:8080
```

---

## 🧹 Supprimer les ressources Azure

Quand tu n'en as plus besoin, supprime le Resource Group entier (VM, IP publique, NSG, disque) :

```bash
az group delete --name rg-productmanager-demo --yes --no-wait
```

Ou depuis le portail : **Resource groups** → `rg-productmanager-demo` → **Delete resource group**.

---

## 📋 Récapitulatif des ports

| Port | Usage | Ouvert dans le NSG |
|---|---|---|
| `22` | SSH — accès à la VM | ✅ Automatique |
| `8080` | API ProductManager | ✅ À ajouter manuellement |
