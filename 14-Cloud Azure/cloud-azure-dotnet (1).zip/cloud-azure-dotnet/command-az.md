# 🔰 NIVEAU 1 — Bases absolues

## Table of Contents

<details>

   <summary>Contents</summary>

1. [1️⃣ Vérifier la version](#1-vrifier-la-version)
1. [2️⃣ Se connecter](#2-se-connecter)
1. [3️⃣ Lister les abonnements](#3-lister-les-abonnements)
1. [4️⃣ Définir l’abonnement actif](#4-dfinir-labonnement-actif)
1. [5️⃣ Voir le compte actif](#5-voir-le-compte-actif)
1. [6️⃣ Créer un Resource Group](#6-crer-un-resource-group)
1. [7️⃣ Lister les Resource Groups](#7-lister-les-resource-groups)
1. [8️⃣ Voir le détail d’un RG](#8-voir-le-dtail-dun-rg)
1. [9️⃣ Supprimer un RG (⚠️ destructif)](#9-supprimer-un-rg--destructif)
1. [🔟 Créer une VM Linux simple](#-crer-une-vm-linux-simple)
1. [1️⃣1️⃣ Lister les VMs](#11-lister-les-vms)
1. [1️⃣2️⃣ Démarrer / Stopper une VM](#12-dmarrer--stopper-une-vm)
1. [1️⃣3️⃣ Se connecter en SSH](#13-se-connecter-en-ssh)
1. [1️⃣4️⃣ Créer un VNet](#14-crer-un-vnet)
1. [1️⃣5️⃣ Ouvrir le port 80 sur une VM](#15-ouvrir-le-port-80-sur-une-vm)
1. [1️⃣6️⃣ Lister les NSG rules](#16-lister-les-nsg-rules)
1. [1️⃣7️⃣ Créer un Storage Account](#17-crer-un-storage-account)
1. [1️⃣8️⃣ Créer un container Blob](#18-crer-un-container-blob)
1. [1️⃣9️⃣ Upload d’un fichier](#19-upload-dun-fichier)
1. [2️⃣0️⃣ Lister les rôles](#20-lister-les-rles)
1. [2️⃣1️⃣ Assigner un rôle](#21-assigner-un-rle)
1. [2️⃣2️⃣ Créer un Service Principal](#22-crer-un-service-principal)
1. [2️⃣3️⃣ Activer le diagnostic d’une VM](#23-activer-le-diagnostic-dune-vm)
1. [2️⃣4️⃣ Voir les logs activité](#24-voir-les-logs-activit)
1. [2️⃣5️⃣ Déployer un template ARM](#25-dployer-un-template-arm)
1. [2️⃣6️⃣ Déployer avec Bicep](#26-dployer-avec-bicep)
1. [2️⃣7️⃣ Login Service Principal (CI/CD)](#27-login-service-principal-cicd)
1. [Format de sortie](#format-de-sortie)
1. [Requête JMESPath (filtrage JSON)](#requte-jmespath-filtrage-json)
1. [Mode debug](#mode-debug)

</details>

## 1️⃣ Vérifier la version

```bash
az version
```

👉 Vérifie que Azure CLI est installé
👉 Affiche la version des modules

---

## 2️⃣ Se connecter

```bash
az login
```

ou

```bash
az login --use-device-code
```

---

## 3️⃣ Lister les abonnements

```bash
az account list -o table
```

---

## 4️⃣ Définir l’abonnement actif

```bash
az account set --subscription "<ID_ou_NOM>"
```

---

## 5️⃣ Voir le compte actif

```bash
az account show
```

---

# 🟢 NIVEAU 2 — Gestion des Resource Groups

Les Resource Groups sont la base de toute infra Azure.

---

## 6️⃣ Créer un Resource Group

```bash
az group create \
  --name rg-demo-cli \
  --location westeurope
```

---

## 7️⃣ Lister les Resource Groups

```bash
az group list -o table
```

---

## 8️⃣ Voir le détail d’un RG

```bash
az group show --name rg-demo-cli
```

---

## 9️⃣ Supprimer un RG (⚠️ destructif)

```bash
az group delete --name rg-demo-cli --yes --no-wait
```

---

# 🟡 NIVEAU 3 — Gestion d’une VM

---

## 🔟 Créer une VM Linux simple

```bash
az vm create \
  --resource-group rg-demo-cli \
  --name vm-demo \
  --image Ubuntu2204 \
  --admin-username azureuser \
  --generate-ssh-keys
```

---

## 1️⃣1️⃣ Lister les VMs

```bash
az vm list -o table
```

---

## 1️⃣2️⃣ Démarrer / Stopper une VM

```bash
az vm stop --name vm-demo --resource-group rg-demo-cli
az vm start --name vm-demo --resource-group rg-demo-cli
```

---

## 1️⃣3️⃣ Se connecter en SSH

```bash
az vm show --name vm-demo --resource-group rg-demo-cli -d -o table
```

Puis :

```bash
ssh azureuser@IP_PUBLIQUE
```

---

# 🟠 NIVEAU 4 — Réseau

---

## 1️⃣4️⃣ Créer un VNet

```bash
az network vnet create \
  --resource-group rg-demo-cli \
  --name vnet-demo \
  --address-prefix 10.0.0.0/16 \
  --subnet-name subnet-demo \
  --subnet-prefix 10.0.1.0/24
```

---

## 1️⃣5️⃣ Ouvrir le port 80 sur une VM

```bash
az vm open-port \
  --port 80 \
  --resource-group rg-demo-cli \
  --name vm-demo
```

---

## 1️⃣6️⃣ Lister les NSG rules

```bash
az network nsg rule list \
  --resource-group rg-demo-cli \
  --nsg-name vm-demoNSG
```

---

# 🔵 NIVEAU 5 — Stockage

---

## 1️⃣7️⃣ Créer un Storage Account

```bash
az storage account create \
  --name demostoragecli123 \
  --resource-group rg-demo-cli \
  --location westeurope \
  --sku Standard_LRS
```

---

## 1️⃣8️⃣ Créer un container Blob

```bash
az storage container create \
  --name data \
  --account-name demostoragecli123
```

---

## 1️⃣9️⃣ Upload d’un fichier

```bash
az storage blob upload \
  --account-name demostoragecli123 \
  --container-name data \
  --name test.txt \
  --file ./test.txt
```

---

# 🟣 NIVEAU 6 — RBAC & Sécurité

---

## 2️⃣0️⃣ Lister les rôles

```bash
az role definition list -o table
```

---

## 2️⃣1️⃣ Assigner un rôle

```bash
az role assignment create \
  --assignee user@domain.com \
  --role Contributor \
  --scope /subscriptions/<SUB_ID>
```

---

## 2️⃣2️⃣ Créer un Service Principal

```bash
az ad sp create-for-rbac \
  --name sp-demo-cli \
  --role contributor \
  --scopes /subscriptions/<SUB_ID>
```

---

# 🔴 NIVEAU 7 — Monitoring & Logs

---

## 2️⃣3️⃣ Activer le diagnostic d’une VM

```bash
az monitor diagnostic-settings create ...
```

---

## 2️⃣4️⃣ Voir les logs activité

```bash
az monitor activity-log list --max-events 10
```

---

# ⚫ NIVEAU 8 — Avancé / DevOps

---

## 2️⃣5️⃣ Déployer un template ARM

```bash
az deployment group create \
  --resource-group rg-demo-cli \
  --template-file template.json
```

---

## 2️⃣6️⃣ Déployer avec Bicep

```bash
az deployment group create \
  --resource-group rg-demo-cli \
  --template-file main.bicep
```

---

## 2️⃣7️⃣ Login Service Principal (CI/CD)

```bash
az login --service-principal \
  --username <appId> \
  --password <secret> \
  --tenant <tenant>
```

---

# 🧠 Astuces importantes

## Format de sortie

```bash
-o table
-o json
-o yaml
```

---

## Requête JMESPath (filtrage JSON)

```bash
az vm list --query "[].name"
```

---

## Mode debug

```bash
--debug
```

---

# 📈 Progression pédagogique idéale

1. Login
2. RG
3. VM
4. Réseau
5. Stockage
6. RBAC
7. Monitoring
8. Infra as Code

---
