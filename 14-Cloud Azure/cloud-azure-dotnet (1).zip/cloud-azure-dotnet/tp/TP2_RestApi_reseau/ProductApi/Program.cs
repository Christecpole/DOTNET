using Microsoft.EntityFrameworkCore;
using ProductApi.Data;

var builder = WebApplication.CreateBuilder(args);

// === PostgreSQL avec Npgsql ===
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? "Host=localhost;Port=5432;Database=productsdb;Username=apiuser;Password=ApiPass2024!";

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(connectionString, npgsql =>
    {
        npgsql.EnableRetryOnFailure(
            maxRetryCount: 10,
            maxRetryDelay: TimeSpan.FromSeconds(30),
            errorCodesToAdd: null);
        npgsql.CommandTimeout(60);
    }));

// === Controllers + Swagger ===
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() {
        Title = "Products API",
        Version = "v1",
        Description = "API REST .NET 8 + EF Core + PostgreSQL"
    });
});

// === CORS ===
builder.Services.AddCors(options =>
    options.AddDefaultPolicy(policy =>
        policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

// === Health Checks ===
builder.Services.AddHealthChecks()
    .AddDbContextCheck<AppDbContext>("postgresql");

var app = builder.Build();

// === Auto-création de la base au démarrage ===
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var retries = 0;
    while (retries < 20)
    {
        try
        {
            app.Logger.LogInformation("Connexion PostgreSQL ({attempt}/20)...", retries + 1);
            db.Database.EnsureCreated();
            app.Logger.LogInformation("✅ Base PostgreSQL créée !");
            break;
        }
        catch (Exception ex)
        {
            retries++;
            app.Logger.LogWarning("⏳ PostgreSQL pas prêt ({attempt}/20): {msg}", retries, ex.Message);
            if (retries >= 20) throw;
            Thread.Sleep(3000);
        }
    }
}

// === Middleware ===
app.UseCors();
app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Products API v1"));
app.MapHealthChecks("/healthz");
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger"));

app.Run();
