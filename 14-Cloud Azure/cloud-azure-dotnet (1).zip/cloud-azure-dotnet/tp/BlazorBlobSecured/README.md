# Blazor Blob Images — Sécurisé avec SAS Tokens

Application Blazor Server (.NET 8) de gestion d'images avec Azure Blob Storage SDK.  
Le conteneur est **privé** : les images sont accessibles uniquement via des **SAS Tokens** temporaires.

---

## Fonctionnalités

- **Upload** simple ou multiple avec validation MIME et taille (10 Mo max)
- **Galerie** responsive avec aperçu, métadonnées et badge d'expiration SAS
- **Suppression** avec modale de confirmation
- **Sécurité** : conteneur privé, URLs signées (SAS) en lecture seule, expiration 30 min

---

## 1. Commandes Azure CLI — Provisionner l'infrastructure

```bash
# ══════════════════════════════════════════════════════════
# Variables (à personnaliser)
# ══════════════════════════════════════════════════════════
RESOURCE_GROUP="rg-blob-images"
LOCATION="francecentral"
STORAGE_ACCOUNT="stblobimages$RANDOM"
CONTAINER_NAME="images"

# ══════════════════════════════════════════════════════════
# Étape 1 : Créer le Resource Group
# ══════════════════════════════════════════════════════════
az group create \
  --name $RESOURCE_GROUP \
  --location $LOCATION

# ══════════════════════════════════════════════════════════
# Étape 2 : Créer le Storage Account (accès public désactivé)
# ══════════════════════════════════════════════════════════
az storage account create \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --sku Standard_LRS \
  --kind StorageV2 \
  --access-tier Hot \
  --min-tls-version TLS1_2 \
  --allow-blob-public-access false

# ══════════════════════════════════════════════════════════
# Étape 3 : Récupérer la clé d'accès
# ══════════════════════════════════════════════════════════
STORAGE_KEY=$(az storage account keys list \
  --account-name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --query "[0].value" \
  --output tsv)

# ══════════════════════════════════════════════════════════
# Étape 4 : Créer le conteneur Blob (ACCÈS PRIVÉ)
# ══════════════════════════════════════════════════════════
az storage container create \
  --name $CONTAINER_NAME \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --public-access off

# ══════════════════════════════════════════════════════════
# Étape 5 : Récupérer la Connection String
# ══════════════════════════════════════════════════════════
CONNECTION_STRING=$(az storage account show-connection-string \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --query "connectionString" \
  --output tsv)

# ══════════════════════════════════════════════════════════
# Étape 6 : (Optionnel) Activer le soft-delete (7 jours)
# ══════════════════════════════════════════════════════════
az storage blob service-properties delete-policy update \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --enable true \
  --days-retained 7

# ══════════════════════════════════════════════════════════
# Résumé
# ══════════════════════════════════════════════════════════
echo ""
echo "════════════════════════════════════════════════════"
echo " INFRASTRUCTURE CRÉÉE"
echo "════════════════════════════════════════════════════"
echo " Resource Group  : $RESOURCE_GROUP"
echo " Storage Account : $STORAGE_ACCOUNT"
echo " Container       : $CONTAINER_NAME (accès privé)"
echo " Soft-delete     : 7 jours"
echo ""
echo " Connection String :"
echo " $CONNECTION_STRING"
echo "════════════════════════════════════════════════════"
```

### Vérifications

```bash
# Accès public désactivé ?
az storage account show \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --query "allowBlobPublicAccess"
# → false

# Conteneur privé ?
az storage container show \
  --name $CONTAINER_NAME \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --query "properties.publicAccess"
# → null

# Lister les blobs
az storage blob list \
  --container-name $CONTAINER_NAME \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --output table
```

### Nettoyage

```bash
az group delete --name $RESOURCE_GROUP --yes --no-wait
```

---

## 2. Configuration du projet

Copier la `ConnectionString` dans `appsettings.json` :

```json
{
  "AzureBlobStorage": {
    "ConnectionString": "COLLER_ICI",
    "ContainerName": "images",
    "SasTokenDurationMinutes": 30
  }
}
```

---

## 3. Lancement

```bash
dotnet restore
dotnet run
```

Ouvrir : `https://localhost:7200`

---

## 4. Architecture

```
BlazorBlobImages/
├── Program.cs                          # DI, Blazor Server, init conteneur privé
├── BlazorBlobImages.csproj             # Azure.Storage.Blobs
├── appsettings.json                    # ConnectionString + SAS duration
├── Models/
│   └── BlobImageInfo.cs                # DTO avec SasExpiration + SasTimeRemaining
├── Services/
│   ├── IBlobStorageService.cs          # Interface
│   └── BlobStorageService.cs           # Upload, List, Delete + SAS Token
├── Components/
│   ├── App.razor                       # HTML racine
│   ├── Routes.razor                    # Router
│   ├── _Imports.razor                  # Usings globaux
│   ├── Layout/
│   │   └── MainLayout.razor            # Navbar + footer
│   └── Pages/
│       └── Home.razor                  # Galerie sécurisée
├── wwwroot/css/
│   └── app.css                         # Styles
└── Properties/
    └── launchSettings.json
```

---

## 5. Sécurité

```
┌──────────┐     Upload / List     ┌──────────────┐     SDK Azure      ┌─────────────────┐
│  Browser  │ ◀──────────────────▶ │  Blazor      │ ◀────────────────▶ │  Azure Blob     │
│           │                      │  Server      │                     │  Storage        │
│           │                      │              │                     │  (PRIVÉ)        │
│           │  <img src="SAS URL"> │  Génère SAS  │                     │                 │
│           │ ─────────────────────────────────────────────────────────▶│                 │
│           │  ◀──────── image data (si SAS valide, < 30 min) ────────│                 │
└──────────┘                      └──────────────┘                     └─────────────────┘
```

| Protection | Détail |
|---|---|
| Conteneur privé | `--public-access off` + `PublicAccessType.None` |
| Accès public bloqué | `--allow-blob-public-access false` au niveau du compte |
| SAS Token | URL signée, lecture seule (`sp=r`), expiration 30 min |
| TLS 1.2 | `--min-tls-version TLS1_2` |
| Soft-delete | Récupération des images supprimées pendant 7 jours |
| Validation serveur | Type MIME + taille max 10 Mo |
