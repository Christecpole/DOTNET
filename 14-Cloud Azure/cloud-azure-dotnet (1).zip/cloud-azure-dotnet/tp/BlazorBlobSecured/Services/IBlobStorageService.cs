using BlazorBlobImages.Models;

namespace BlazorBlobImages.Services;

public interface IBlobStorageService
{
    Task InitializeAsync();
    Task<(bool Success, string Message, string? Uri, string? FileName)> UploadImageAsync(
        string fileName, Stream content, string contentType);
    Task<List<BlobImageInfo>> ListImagesAsync();
    Task<(bool Success, string Message)> DeleteImageAsync(string blobName);
}
