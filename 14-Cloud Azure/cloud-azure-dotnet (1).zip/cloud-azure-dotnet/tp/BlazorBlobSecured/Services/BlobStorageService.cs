using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using BlazorBlobImages.Models;

namespace BlazorBlobImages.Services;

public class BlobStorageService : IBlobStorageService
{
    private readonly BlobServiceClient _blobServiceClient;
    private readonly BlobContainerClient _containerClient;
    private readonly ILogger<BlobStorageService> _logger;
    private readonly int _sasTokenDurationMinutes;

    private static readonly HashSet<string> AllowedContentTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        "image/jpeg", "image/png", "image/gif", "image/webp", "image/bmp", "image/svg+xml"
    };

    private const long MaxFileSize = 10 * 1024 * 1024; // 10 Mo

    public BlobStorageService(
        BlobServiceClient blobServiceClient,
        IConfiguration configuration,
        ILogger<BlobStorageService> logger)
    {
        _blobServiceClient = blobServiceClient;
        _logger = logger;

        var containerName = configuration["AzureBlobStorage:ContainerName"] ?? "images";
        _sasTokenDurationMinutes = int.Parse(configuration["AzureBlobStorage:SasTokenDurationMinutes"] ?? "30");
        _containerClient = blobServiceClient.GetBlobContainerClient(containerName);
    }

    // ══════════════════════════ INIT ══════════════════════════

    public async Task InitializeAsync()
    {
        // Conteneur PRIVÉ : aucun accès anonyme
        await _containerClient.CreateIfNotExistsAsync(PublicAccessType.None);
        _logger.LogInformation("Conteneur '{Container}' initialisé (privé, SAS {Duration} min).",
            _containerClient.Name, _sasTokenDurationMinutes);
    }

    // ══════════════════════════ SAS TOKEN ══════════════════════════

    /// <summary>
    /// Génère une URL signée (SAS) en lecture seule avec expiration configurable
    /// </summary>
    private (string Uri, DateTimeOffset Expiration) GenerateSasUri(BlobClient blobClient)
    {
        if (!blobClient.CanGenerateSasUri)
            throw new InvalidOperationException(
                "Impossible de générer un SAS Token. " +
                "Vérifiez que la ConnectionString contient la clé du compte (AccountKey).");

        var expiration = DateTimeOffset.UtcNow.AddMinutes(_sasTokenDurationMinutes);

        var sasBuilder = new BlobSasBuilder
        {
            BlobContainerName = blobClient.BlobContainerName,
            BlobName = blobClient.Name,
            Resource = "b",                                     // b = blob individuel
            StartsOn = DateTimeOffset.UtcNow.AddMinutes(-5),    // tolérance horloge
            ExpiresOn = expiration
        };

        sasBuilder.SetPermissions(BlobSasPermissions.Read); // Lecture seule

        var sasUri = blobClient.GenerateSasUri(sasBuilder).ToString();
        return (sasUri, expiration);
    }

    // ══════════════════════════ UPLOAD ══════════════════════════

    public async Task<(bool Success, string Message, string? Uri, string? FileName)> UploadImageAsync(
        string fileName, Stream content, string contentType)
    {
        if (!AllowedContentTypes.Contains(contentType))
            return (false, $"Type non autorisé : {contentType}", null, null);

        if (content.Length > MaxFileSize)
            return (false, $"Fichier trop volumineux ({content.Length / (1024 * 1024)} Mo). Max : 10 Mo.", null, null);

        try
        {
            var extension = Path.GetExtension(fileName);
            var uniqueName = $"{Guid.NewGuid()}{extension}";
            var blobClient = _containerClient.GetBlobClient(uniqueName);

            await blobClient.UploadAsync(content, new BlobUploadOptions
            {
                HttpHeaders = new BlobHttpHeaders { ContentType = contentType },
                Metadata = new Dictionary<string, string>
                {
                    { "originalFileName", fileName },
                    { "uploadedAt", DateTimeOffset.UtcNow.ToString("o") }
                }
            });

            // Retourner URL signée (pas l'URL publique)
            var (sasUri, _) = GenerateSasUri(blobClient);

            _logger.LogInformation("Image '{Original}' uploadée sous '{Blob}'.", fileName, uniqueName);
            return (true, "Image uploadée avec succès.", sasUri, uniqueName);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erreur upload '{FileName}'.", fileName);
            return (false, $"Erreur : {ex.Message}", null, null);
        }
    }

    // ══════════════════════════ LIST ══════════════════════════

    public async Task<List<BlobImageInfo>> ListImagesAsync()
    {
        var images = new List<BlobImageInfo>();

        await foreach (var blob in _containerClient.GetBlobsAsync(BlobTraits.Metadata))
        {
            var blobClient = _containerClient.GetBlobClient(blob.Name);

            // Générer un SAS Token pour chaque image
            var (sasUri, expiration) = GenerateSasUri(blobClient);

            images.Add(new BlobImageInfo
            {
                Name = blob.Name,
                Uri = sasUri,
                ContentType = blob.Properties.ContentType ?? "unknown",
                Size = blob.Properties.ContentLength ?? 0,
                LastModified = blob.Properties.LastModified,
                SasExpiration = expiration
            });
        }

        _logger.LogInformation("{Count} image(s) listée(s) avec SAS Tokens.", images.Count);
        return images.OrderByDescending(i => i.LastModified).ToList();
    }

    // ══════════════════════════ DELETE ══════════════════════════

    public async Task<(bool Success, string Message)> DeleteImageAsync(string blobName)
    {
        try
        {
            var response = await _containerClient.GetBlobClient(blobName)
                .DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots);

            if (response.Value)
            {
                _logger.LogInformation("Image '{Blob}' supprimée.", blobName);
                return (true, "Image supprimée avec succès.");
            }
            return (false, "Image introuvable.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erreur suppression '{Blob}'.", blobName);
            return (false, $"Erreur : {ex.Message}");
        }
    }
}
