namespace BlazorBlobImages.Models;

public class BlobImageInfo
{
    public string Name { get; set; } = string.Empty;
    public string Uri { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public long Size { get; set; }
    public DateTimeOffset? LastModified { get; set; }
    public DateTimeOffset? SasExpiration { get; set; }

    public string SizeFormatted
    {
        get
        {
            if (Size < 1024) return $"{Size} o";
            if (Size < 1024 * 1024) return $"{Size / 1024.0:F1} Ko";
            return $"{Size / (1024.0 * 1024.0):F2} Mo";
        }
    }

    /// <summary>
    /// Temps restant avant expiration du SAS Token
    /// </summary>
    public string SasTimeRemaining
    {
        get
        {
            if (SasExpiration == null) return "—";
            var remaining = SasExpiration.Value - DateTimeOffset.UtcNow;
            if (remaining.TotalSeconds <= 0) return "Expiré";
            return $"{(int)remaining.TotalMinutes} min";
        }
    }
}
