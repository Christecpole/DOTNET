using Azure.Storage.Blobs;
using BlazorBlobImages.Components;
using BlazorBlobImages.Services;

var builder = WebApplication.CreateBuilder(args);

// ──────────── Blazor Server ────────────
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// ──────────── Azure Blob Storage ────────────
var connectionString = builder.Configuration["AzureBlobStorage:ConnectionString"]
    ?? throw new InvalidOperationException("AzureBlobStorage:ConnectionString manquante.");

builder.Services.AddSingleton(new BlobServiceClient(connectionString));
builder.Services.AddScoped<IBlobStorageService, BlobStorageService>();

var app = builder.Build();

// ──────────── Init conteneur (accès privé) ────────────
using (var scope = app.Services.CreateScope())
{
    var blobService = (BlobStorageService)scope.ServiceProvider.GetRequiredService<IBlobStorageService>();
    await blobService.InitializeAsync();
}

// ──────────── Pipeline ────────────
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
