# TP — Azure Blob Storage : Implémenter List et Delete

## Contexte

Vous travaillez sur une application **Blazor Server (.NET 8)** qui gère des images dans **Azure Blob Storage**. Le conteneur est **privé** et les images sont accessibles uniquement via des **SAS Tokens** temporaires (URLs signées avec expiration).

Le service `BlobStorageService` est partiellement implémenté : la méthode **Upload** fonctionne déjà. Votre mission est de compléter les méthodes **ListImagesAsync** et **DeleteImageAsync**, puis de configurer la connexion Azure.

---

## Objectifs pédagogiques

À la fin de ce TP, vous serez capable de :

- Provisionner un Storage Account et un conteneur Blob sur Azure
- Lister les blobs d'un conteneur Azure avec le SDK `Azure.Storage.Blobs`
- Générer des URLs sécurisées (SAS Tokens) pour chaque blob
- Supprimer un blob avec gestion des erreurs
- Configurer la connexion à un Storage Account Azure

---

## Prérequis

- .NET 8 SDK installé
- Azure CLI installé et connecté (`az login`)
- Le projet Blazor fourni avec l'upload fonctionnel

---

## Partie 0 — Provisionner l'infrastructure Azure

Avant de coder, il faut créer les ressources Azure nécessaires.

### Exercice 0.1 — Définir les variables

Ouvrez un terminal et définissez les variables suivantes (personnalisez le nom du Storage Account) :

```bash
RESOURCE_GROUP="rg-blob-images"
LOCATION="francecentral"
STORAGE_ACCOUNT="stblobimages$RANDOM"
CONTAINER_NAME="images"
```

> **Note** : Le nom du Storage Account doit être **unique dans tout Azure**, en **minuscules**, entre 3 et 24 caractères, sans tirets ni caractères spéciaux. La variable `$RANDOM` génère un suffixe aléatoire.

### Exercice 0.2 — Créer le Resource Group

```bash
az group create \
  --name $RESOURCE_GROUP \
  --location $LOCATION
```

> **Question** : Qu'est-ce qu'un Resource Group dans Azure ? Pourquoi regroupe-t-on les ressources ?

### Exercice 0.3 — Créer le Storage Account

```bash
az storage account create \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --sku Standard_LRS \
  --kind StorageV2 \
  --access-tier Hot \
  --min-tls-version TLS1_2 \
  --allow-blob-public-access false
```

> **Question** : À quoi sert le paramètre `--allow-blob-public-access false` ? Quel est l'impact sur la sécurité ?

### Exercice 0.4 — Récupérer la clé d'accès

```bash
STORAGE_KEY=$(az storage account keys list \
  --account-name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --query "[0].value" \
  --output tsv)
```

Vérifiez que la clé a bien été récupérée :

```bash
echo $STORAGE_KEY
```

### Exercice 0.5 — Créer le conteneur Blob (accès privé)

```bash
az storage container create \
  --name $CONTAINER_NAME \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --public-access off
```

> **Question** : Quelle est la différence entre `--public-access off`, `--public-access blob` et `--public-access container` ?

### Exercice 0.6 — Récupérer la Connection String

```bash
CONNECTION_STRING=$(az storage account show-connection-string \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --query "connectionString" \
  --output tsv)

echo $CONNECTION_STRING
```

**Copiez cette valeur**, vous en aurez besoin dans la partie suivante.

### Exercice 0.7 — (Optionnel) Activer le soft-delete

```bash
az storage blob service-properties delete-policy update \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --enable true \
  --days-retained 7
```

> **Question** : Quel est l'intérêt du soft-delete dans le cadre de ce TP ?

### Vérifications

```bash
# Le Storage Account est bien créé ?
az storage account show \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --query "{name:name, location:location, publicAccess:allowBlobPublicAccess}" \
  --output table

# Le conteneur existe et est privé ?
az storage container show \
  --name $CONTAINER_NAME \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --query "{name:name, publicAccess:properties.publicAccess}" \
  --output table
```

Vous devez voir `publicAccess` à `null` (= privé) et `allowBlobPublicAccess` à `false`.

---

## Partie 1 — Configuration du projet (appsettings.json)

### Exercice 1.1 — Compléter appsettings.json

Ouvrez le fichier `appsettings.json` et collez la **Connection String** récupérée à l'exercice 0.6 :

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "AzureBlobStorage": {
    "ConnectionString": "____________À_COMPLÉTER____________",
    "ContainerName": "images",
    "SasTokenDurationMinutes": 30
  }
}
```

> **Question** : À quoi sert le paramètre `SasTokenDurationMinutes` ? Que se passe-t-il si on met une valeur de `1` ?

---

## Partie 2 — Implémenter ListImagesAsync

### Contexte

La méthode `ListImagesAsync` doit parcourir tous les blobs du conteneur et retourner une liste d'objets `BlobImageInfo` contenant les métadonnées de chaque image **ainsi qu'une URL sécurisée (SAS Token)**.

### Code de départ

```csharp
public async Task<List<BlobImageInfo>> ListImagesAsync()
{

    return null;
}
```

### Exercice 2.1 — Implémenter la méthode

Complétez la méthode `ListImagesAsync` en suivant ces étapes :

1. Créer une liste vide de `BlobImageInfo`
2. Parcourir les blobs du conteneur avec `_containerClient.GetBlobsAsync(BlobTraits.Metadata)`
3. Pour chaque blob :
   - Récupérer un `BlobClient` via `_containerClient.GetBlobClient(blob.Name)`
   - Générer une URL signée en appelant la méthode `GenerateSasUri(blobClient)` (déjà implémentée dans le service)
   - Créer un objet `BlobImageInfo` avec les propriétés suivantes :

| Propriété | Source |
|---|---|
| `Name` | `blob.Name` |
| `Uri` | L'URL SAS générée |
| `ContentType` | `blob.Properties.ContentType` |
| `Size` | `blob.Properties.ContentLength` |
| `LastModified` | `blob.Properties.LastModified` |
| `SasExpiration` | La date d'expiration retournée par `GenerateSasUri` |

4. Ajouter l'objet à la liste
5. Retourner la liste triée par date de modification décroissante

### Indices

- La méthode `GenerateSasUri` retourne un **tuple** `(string Uri, DateTimeOffset Expiration)`. Pour récupérer les deux valeurs :

```csharp
var (sasUri, expiration) = GenerateSasUri(blobClient);
```

- Pour parcourir un `AsyncPageable`, utilisez `await foreach` :

```csharp
await foreach (var blob in _containerClient.GetBlobsAsync(...))
{
    // ...
}
```

- Pour trier par date décroissante :

```csharp
return maListe.OrderByDescending(i => i.LastModified).ToList();
```

> **Question** : Pourquoi génère-t-on un SAS Token pour chaque image au lieu de retourner l'URL publique du blob ?

---

## Partie 3 — Implémenter DeleteImageAsync

### Contexte

La méthode `DeleteImageAsync` doit supprimer un blob par son nom et retourner un résultat indiquant le succès ou l'échec de l'opération.

### Code de départ

```csharp
public async Task<(bool Success, string Message)> DeleteImageAsync(string blobName)
{
    
        return (false, "rien : rien");
    
}
```

### Exercice 3.1 — Implémenter la méthode

Complétez la méthode `DeleteImageAsync` en suivant ces étapes :

1. Encapsuler tout le code dans un bloc `try / catch`
2. Dans le `try` :
   - Récupérer un `BlobClient` via `_containerClient.GetBlobClient(blobName)`
   - Appeler `DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots)` sur le client
   - Vérifier `response.Value` : si `true`, le blob a été supprimé → retourner `(true, "Image supprimée avec succès.")`
   - Si `false`, le blob n'existait pas → retourner `(false, "Image introuvable.")`
3. Dans le `catch(Exception ex)` :
   - Logger l'erreur avec `_logger.LogError(...)`
   - Retourner `(false, $"Erreur : {ex.Message}")`

### Indices

- `DeleteIfExistsAsync` retourne un `Response<bool>`. La propriété `.Value` indique si le blob existait et a été supprimé :

```csharp
var response = await blobClient.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots);
if (response.Value)
{
    // Le blob a été supprimé
}
```

- `DeleteSnapshotsOption.IncludeSnapshots` supprime aussi les éventuels snapshots du blob

> **Question** : Quelle est la différence entre `DeleteAsync` et `DeleteIfExistsAsync` ? Laquelle est préférable ici et pourquoi ?

---

## Partie 4 — Vérification

### 4.1 — Lancer l'application

```bash
dotnet run
```

### 4.2 — Tester le workflow complet

1. **Uploader** une ou plusieurs images via l'interface
2. **Vérifier** que la galerie affiche les images avec le badge d'expiration SAS
3. **Cliquer** sur "Voir" pour ouvrir l'image via son URL SAS
4. **Supprimer** une image et vérifier qu'elle disparaît de la galerie
5. **Attendre** l'expiration du SAS Token (ou mettre `SasTokenDurationMinutes` à `1`) puis cliquer sur "Voir" → vous devez obtenir une erreur

### 4.3 — Vérifier avec Azure CLI

```bash
# Lister les blobs dans le conteneur
az storage blob list \
  --container-name images \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --output table

# Vérifier qu'un blob supprimé n'apparaît plus (relancer après suppression)
az storage blob list \
  --container-name images \
  --account-name $STORAGE_ACCOUNT \
  --account-key $STORAGE_KEY \
  --output table
```

---

## Bonus

### Bonus 1 — Ajouter des logs

Ajoutez des logs `_logger.LogInformation(...)` dans vos deux méthodes pour tracer :
- Le nombre d'images listées
- Le nom du blob supprimé

### Bonus 2 — Durée SAS configurable

Modifiez la valeur `SasTokenDurationMinutes` dans `appsettings.json` à `5` puis à `60`. Observez l'impact sur les badges d'expiration dans la galerie.

### Bonus 3 — Gestion d'erreurs avancée

Que se passe-t-il si `blobName` contient des caractères spéciaux ou est vide ? Ajoutez une validation en début de `DeleteImageAsync` pour gérer ces cas.

---

## Nettoyage

À la fin du TP, supprimez toutes les ressources Azure pour éviter des coûts :

```bash
az group delete --name $RESOURCE_GROUP --yes --no-wait
```

> **Note** : `--no-wait` lance la suppression en arrière-plan. La suppression complète peut prendre quelques minutes.

---

## Rappel — Modèle BlobImageInfo

```csharp
public class BlobImageInfo
{
    public string Name { get; set; } = string.Empty;
    public string Uri { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public long Size { get; set; }
    public DateTimeOffset? LastModified { get; set; }
    public DateTimeOffset? SasExpiration { get; set; }
    // ...
}
```

## Rappel — Signature de GenerateSasUri (déjà implémentée)

```csharp
private (string Uri, DateTimeOffset Expiration) GenerateSasUri(BlobClient blobClient)
```

Cette méthode est **déjà disponible** dans le service. Elle retourne un tuple contenant l'URL signée et la date d'expiration.
