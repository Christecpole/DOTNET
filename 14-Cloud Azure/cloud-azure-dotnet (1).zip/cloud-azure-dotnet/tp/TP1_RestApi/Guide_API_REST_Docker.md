# 🚀 API REST .NET 8 + MySQL — Déploiement Docker

> **Stack** : ASP.NET Core 8 · Entity Framework Core · MySQL 8.0 · Docker Compose  
> **API** : CRUD Products & Categories avec Swagger, pagination, filtres, health checks  
> **Persistance** : MySQL conteneurisé avec volume Docker

---

## 📁 Structure du projet

```
RestApi/
├── docker-compose.yml          # Orchestration API + MySQL
├── Dockerfile                  # Multi-stage build .NET 8
├── .dockerignore
├── RestApi.sln
└── RestApi/
    ├── RestApi.csproj          # Pomelo.EF.MySql + Swashbuckle
    ├── Program.cs              # Config MySQL + Swagger + auto-create DB
    ├── appsettings.json
    ├── Data/
    │   └── AppDbContext.cs     # DbContext + seed data
    ├── Models/
    │   ├── Product.cs
    │   ├── Category.cs
    │   └── Dtos.cs             # Record DTOs (Create/Update/Read)
    └── Controllers/
        ├── ProductsController.cs    # GET/POST/PUT/DELETE + pagination + filtres
        └── CategoriesController.cs  # CRUD + GET /{id}/products
```

---

## 📋 Prérequis

- .NET 8 SDK
- Docker Desktop (ou Docker Engine sur Linux)
- Azure CLI (`az`)

```bash
dotnet --version     # 8.0.x
docker --version     # 24.x+
az --version         # 2.x+
```

---

## Étape 1 — Créer le projet (déjà fourni dans le ZIP)

```bash
# Si vous partez de zéro :
dotnet new webapi -n RestApi --framework net8.0 --no-https
cd RestApi

# Ajouter les packages
dotnet add package Pomelo.EntityFrameworkCore.MySql --version 8.0.2
dotnet add package Microsoft.EntityFrameworkCore.Design --version 8.0.11
dotnet add package Swashbuckle.AspNetCore --version 6.9.0
```

### Points clés du code

**Program.cs** — Connexion MySQL avec retry + auto-création de la base :

```csharp
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString),
        mysql =>
        {
            mysql.EnableRetryOnFailure(maxRetryCount: 10,
                maxRetryDelay: TimeSpan.FromSeconds(30),
                errorNumbersToAdd: null);
        }));
```

Le `EnableRetryOnFailure` est essentiel car MySQL met quelques secondes à démarrer dans Docker. L'API retente la connexion jusqu'à 20 fois (boucle dans Program.cs).

**AppDbContext.cs** — Seed data automatique avec 3 catégories et 5 produits.

**DTOs** — Records C# immuables pour séparer le modèle de la réponse API :

```csharp
public record ProductDto(int Id, string Name, string? Description,
    decimal Price, int Stock, bool IsActive, DateTime CreatedAt,
    int CategoryId, string CategoryName);

public record CreateProductDto(
    [Required] string Name, string? Description,
    [Range(0.01, 999999.99)] decimal Price,
    [Range(0, int.MaxValue)] int Stock, int CategoryId);
```

### Endpoints disponibles

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| `GET` | `/api/products` | Liste paginée + filtres (`?categoryId=1&search=laptop&sortBy=price&page=1&pageSize=10`) |
| `GET` | `/api/products/{id}` | Détail d'un produit |
| `POST` | `/api/products` | Créer un produit |
| `PUT` | `/api/products/{id}` | Modifier un produit |
| `DELETE` | `/api/products/{id}` | Supprimer un produit |
| `GET` | `/api/categories` | Liste des catégories (avec compteur produits) |
| `GET` | `/api/categories/{id}` | Détail d'une catégorie |
| `GET` | `/api/categories/{id}/products` | Produits d'une catégorie |
| `POST` | `/api/categories` | Créer une catégorie |
| `PUT` | `/api/categories/{id}` | Modifier une catégorie |
| `DELETE` | `/api/categories/{id}` | Supprimer une catégorie (si vide) |
| `GET` | `/healthz` | Health check (inclut MySQL) |
| `GET` | `/swagger` | Documentation Swagger UI |

---

## Étape 2 — Dockerfile multi-stage

```dockerfile
# STAGE 1 : Build avec le SDK (~900 MB)
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /src
COPY RestApi/RestApi.csproj RestApi/
RUN dotnet restore RestApi/RestApi.csproj
COPY . .
WORKDIR /src/RestApi
RUN dotnet publish -c Release -o /app/publish /p:UseAppHost=false

# STAGE 2 : Runtime léger (~220 MB)
FROM mcr.microsoft.com/dotnet/aspnet:8.0 AS runtime
WORKDIR /app
RUN apt-get update && apt-get install -y --no-install-recommends curl \
    && rm -rf /var/lib/apt/lists/*
RUN adduser --disabled-password --no-create-home appuser
COPY --from=build /app/publish .
USER appuser
EXPOSE 8080
ENV ASPNETCORE_URLS=http://+:8080
HEALTHCHECK --interval=15s --timeout=5s --start-period=30s --retries=5 \
    CMD curl -f http://localhost:8080/healthz || exit 1
ENTRYPOINT ["dotnet", "RestApi.dll"]
```

**Points importants :**

- `COPY .csproj` en premier → cache la couche `dotnet restore` (accélère les rebuilds)
- `curl` installé pour le `HEALTHCHECK`
- Utilisateur `appuser` non-root pour la sécurité
- Port `8080` non-privilégié

---

## Étape 3 — docker-compose.yml

```yaml
version: "3.8"

services:
  mysql:
    image: mysql:8.0
    container_name: mysql-products
    restart: unless-stopped
    environment:
      MYSQL_ROOT_PASSWORD: root123
      MYSQL_DATABASE: productsdb
      MYSQL_USER: apiuser
      MYSQL_PASSWORD: ApiPass2024!
    ports:
      - "3306:3306"
    volumes:
      - mysql_data:/var/lib/mysql
    networks:
      - app-network
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost", "-u", "root", "-proot123"]
      interval: 10s
      timeout: 5s
      retries: 10
      start_period: 30s

  api:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: api-products
    restart: unless-stopped
    ports:
      - "8080:8080"
    environment:
      - ConnectionStrings__DefaultConnection=Server=mysql;Port=3306;Database=productsdb;User=apiuser;Password=ApiPass2024!;
    depends_on:
      mysql:
        condition: service_healthy
    networks:
      - app-network

volumes:
  mysql_data:

networks:
  app-network:
    driver: bridge
```

**Points importants :**

- `depends_on` avec `condition: service_healthy` → l'API ne démarre qu'après que MySQL est prêt
- `mysql_data` volume nommé → les données persistent même si le conteneur est recréé
- `ConnectionStrings__DefaultConnection` → override la connection string via variable d'environnement (le `__` remplace `:` dans la hiérarchie JSON)
- `Server=mysql` → résolution DNS Docker interne (nom du service)
- Le réseau `app-network` permet la communication entre les conteneurs

---

## Étape 4 — Tester en local

```bash
# Se placer à la racine (où se trouve docker-compose.yml)
cd RestApi

# Builder et lancer les 2 conteneurs
docker compose up --build -d

# Vérifier que tout tourne
docker compose ps
# NAME              STATUS                  PORTS
# mysql-products    Up (healthy)            0.0.0.0:3306->3306/tcp
# api-products      Up (healthy)            0.0.0.0:8080->8080/tcp

# Suivre les logs
docker compose logs -f api

# Attendre le message :
# ✅ Base MySQL créée avec succès !
```

### Tester les endpoints

```bash
# Swagger UI
open http://localhost:8080/swagger

# Health check
curl http://localhost:8080/healthz
# Healthy

# Lister les catégories
curl http://localhost:8080/api/categories | jq

# Lister les produits
curl http://localhost:8080/api/products | jq

# Créer un produit
curl -X POST http://localhost:8080/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Souris Ergonomique",
    "description": "Souris verticale sans fil",
    "price": 59.99,
    "stock": 75,
    "categoryId": 1
  }' | jq

# Filtrer par catégorie + tri par prix
curl "http://localhost:8080/api/products?categoryId=1&sortBy=price" | jq

# Recherche
curl "http://localhost:8080/api/products?search=clean" | jq

# Modifier un produit
curl -X PUT http://localhost:8080/api/products/1 \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Laptop Pro 15 - 2024 Edition",
    "description": "Nouveau modèle 32Go RAM",
    "price": 1499.99,
    "stock": 20,
    "isActive": true,
    "categoryId": 1
  }' | jq

# Supprimer un produit
curl -X DELETE http://localhost:8080/api/products/5

# Arrêter
docker compose down
# Avec suppression des données :
# docker compose down -v
```

---

## Étape 5 — Provisionner la VM Azure

```bash
# --- Variables ---
RG="rg-api-demo"
LOCATION="francecentral"
VM_NAME="vm-api"

# --- Connexion Azure ---
az login
az account set --subscription "NomDeLaSubscription"

# --- Resource Group ---
az group create --name $RG --location $LOCATION

# --- Créer la VM Ubuntu 22.04 ---
az vm create \
  --resource-group $RG \
  --name $VM_NAME \
  --image "Ubuntu2204" \
  --size "Standard_B2s" \
  --admin-username "azureuser" \
  --generate-ssh-keys \
  --public-ip-sku Standard

# --- Ouvrir le port 8080 ---
az vm open-port \
  --resource-group $RG \
  --name $VM_NAME \
  --port 8080 \
  --priority 1001

# --- Récupérer l'IP ---
VM_IP=$(az vm show -d -g $RG -n $VM_NAME --query publicIps -o tsv)
echo "VM IP: $VM_IP"
```

---

## Étape 6 — Installer Docker sur la VM

```bash
# Se connecter en SSH
ssh azureuser@$VM_IP

# Installation rapide Docker
curl -fsSL https://get.docker.com | sudo sh

# Ajouter l'utilisateur au groupe docker
sudo usermod -aG docker $USER

# Appliquer (ou se reconnecter)
newgrp docker

# Vérifier
docker --version
docker compose version
```

---

## Étape 7 — Déployer sur la VM

### Option A — Transférer le code et builder sur la VM

```bash
# Depuis votre poste local
scp -r ./RestApi azureuser@$VM_IP:~/RestApi

# Sur la VM (SSH)
cd ~/RestApi
docker compose up --build -d

# Vérifier
docker compose ps
docker compose logs -f api
```

### Option B — Via Azure Container Registry

```bash
# --- Sur votre poste local ---

# Créer un ACR
ACR_NAME="acrapidemo"   # doit être unique
az acr create --name $ACR_NAME -g $RG --sku Basic

# Builder dans le cloud
az acr build --registry $ACR_NAME \
  --image restapi:1.0 \
  --file Dockerfile .

# --- Sur la VM (SSH) ---

# Installer Azure CLI sur la VM
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
az login

# Se connecter à l'ACR
az acr login --name acrapidemo

# Créer un docker-compose-prod.yml
cat > docker-compose.yml << 'EOF'
version: "3.8"
services:
  mysql:
    image: mysql:8.0
    container_name: mysql-products
    restart: unless-stopped
    environment:
      MYSQL_ROOT_PASSWORD: root123
      MYSQL_DATABASE: productsdb
      MYSQL_USER: apiuser
      MYSQL_PASSWORD: ApiPass2024!
    volumes:
      - mysql_data:/var/lib/mysql
    networks:
      - app-network
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost", "-u", "root", "-proot123"]
      interval: 10s
      timeout: 5s
      retries: 10
      start_period: 30s

  api:
    image: acrapidemo.azurecr.io/restapi:1.0
    container_name: api-products
    restart: unless-stopped
    ports:
      - "8080:8080"
    environment:
      - ConnectionStrings__DefaultConnection=Server=mysql;Port=3306;Database=productsdb;User=apiuser;Password=ApiPass2024!;
    depends_on:
      mysql:
        condition: service_healthy
    networks:
      - app-network

volumes:
  mysql_data:
networks:
  app-network:
    driver: bridge
EOF

# Lancer
docker compose up -d
```

---

## Étape 8 — Vérifier le déploiement

```bash
# Sur la VM
docker compose ps
docker compose logs -f api

# Depuis votre poste
curl http://$VM_IP:8080/healthz
curl http://$VM_IP:8080/api/categories | jq
curl http://$VM_IP:8080/api/products | jq

# Swagger UI dans le navigateur :
# http://<VM_IP>:8080/swagger
```

**Vérifications :**

- ✅ `/healthz` retourne `Healthy`
- ✅ `/api/categories` retourne 3 catégories (seed data)
- ✅ `/api/products` retourne 5 produits
- ✅ `POST /api/products` crée un produit persistant (il survit à un `docker compose restart`)
- ✅ Swagger UI fonctionnel et interactif

---

## Étape 9 — Commandes de gestion

| Commande | Description |
|----------|-------------|
| `docker compose ps` | État des conteneurs |
| `docker compose logs -f api` | Logs API temps réel |
| `docker compose logs -f mysql` | Logs MySQL |
| `docker compose restart api` | Redémarrer l'API (sans toucher MySQL) |
| `docker compose down` | Arrêter tout (données conservées) |
| `docker compose down -v` | Arrêter + supprimer les données MySQL |
| `docker compose up --build -d` | Rebuilder et relancer |
| `docker exec -it mysql-products mysql -u apiuser -p productsdb` | Shell MySQL |
| `docker stats` | CPU / RAM / Network live |

### Mise à jour de l'API

```bash
# Modifier le code, puis :
docker compose up --build -d api
# Seul le conteneur API est rebuild, MySQL reste intact
```

### Vérifier la persistance

```bash
# Créer un produit
curl -X POST http://localhost:8080/api/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Persist","price":9.99,"stock":1,"categoryId":1}'

# Redémarrer les conteneurs
docker compose restart

# Vérifier que le produit existe toujours
curl http://localhost:8080/api/products?search=persist | jq
```

---

## Étape 10 — Nettoyage Azure

```bash
# ⚠️ Supprime TOUT le Resource Group (VM, disques, IP, NSG...)
az group delete --name $RG --yes --no-wait

# Vérifier
az group list --query "[?name=='rg-api-demo']" -o table
```

> 💰 **Coût** : Une VM Standard_B2s ≈ 30€/mois. Pensez à supprimer après le lab.

---

## Récapitulatif — Script complet

```bash
#!/bin/bash
# === Déploiement API REST .NET 8 + MySQL sur Azure VM ===

RG="rg-api-demo"
LOCATION="francecentral"
VM_NAME="vm-api"

# 1. Infra Azure
az group create --name $RG --location $LOCATION
az vm create -g $RG --name $VM_NAME \
  --image Ubuntu2204 --size Standard_B2s \
  --admin-username azureuser --generate-ssh-keys
az vm open-port -g $RG --name $VM_NAME --port 8080

# 2. Récupérer l'IP
VM_IP=$(az vm show -d -g $RG -n $VM_NAME --query publicIps -o tsv)

# 3. Transférer le code
scp -r ./RestApi azureuser@$VM_IP:~/RestApi

# 4. Installer Docker + Déployer
ssh azureuser@$VM_IP << 'EOF'
  curl -fsSL https://get.docker.com | sudo sh
  sudo usermod -aG docker $USER
  newgrp docker
  cd ~/RestApi
  docker compose up --build -d
  echo "=== Déployé ! ==="
  docker compose ps
EOF

echo "✅ API disponible sur http://$VM_IP:8080/swagger"
```
